/***************************************************************************//**
* \file Serial_FLASH.c       
* \version 1.0
*
* \brief
* This file provides the source code to the API for the SerialNVRAM 
* Component.
* 
********************************************************************************
* Copyright (2017), Cypress Semiconductor Corporation.
******************************************************************************** 
* \copyright
* Copyright 2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
* CYPRESS PROVIDES THIS SOFTWARE "AS IS" AND MAKES NO WARRANTY OF ANY KIND, 
* EXPRESS OR IMPLIED, WITH REGARD TO THIS SOFTWARE, INCLUDING, BUT NOT LIMITED 
* TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, NON-INFRINGEMENT AND FITNESS 
* FOR A PARTICULAR PURPOSE.
*******************************************************************************/

#include "cytypes.h"
#include "Serial_FLASH.h"

/* Internal constants */
#define Serial_FLASH_DUMMY_BYTE                           (0X22U)

CY_INLINE static void Serial_FLASH_SetDefaultPins(void);

#if (Serial_FLASH_INTERFACE_SPI_SCB == Serial_FLASH_INTERFACE)
    static Serial_FLASH_status Serial_FLASH_SpiSelectDevice(uint8 nvramId);
    static Serial_FLASH_status Serial_FLASH_SpiDeSelectDevice(uint8 nvramId);
    static Serial_FLASH_status Serial_FLASH_SpiTxBusyCheck(void);
    static Serial_FLASH_status Serial_FLASH_SpiRxBufferCheck(void);
    static Serial_FLASH_status Serial_FLASH_SpiSetWriteEnable(uint8 nvramId);
    static Serial_FLASH_status Serial_FLASH_SpiBufferWrite(const uint8 dataWritePtr[], 
                                                                   uint32 totalDataCount);
    static Serial_FLASH_status Serial_FLASH_SpiBufferRead(uint8 dataReadPtr[], 
                                                                  uint32 totalDataCount);
    CY_INLINE static Serial_FLASH_status Serial_FLASH_SpiMemoryWrite(uint8 nvramId, 
                                                                             uint32 addr, 
                                                                             const uint8 *dataWritePtr, 
                                                                             uint32 totalDataCount);
    CY_INLINE static Serial_FLASH_status Serial_FLASH_SpiMemoryRead(uint8 nvramId, 
                                                                            uint32 addr, 
                                                                            uint8 *dataReadPtr, 
                                                                            uint32 totalDataCount);
    CY_INLINE static Serial_FLASH_status Serial_FLASH_SpiRtcRegWrite(uint8 nvramId, 
                                                                             uint32 addr, 
                                                                             const uint8 *dataWritePtr, 
                                                                             uint32 totalDataCount);
    CY_INLINE static Serial_FLASH_status Serial_FLASH_SpiRtcRegRead(uint8 nvramId, 
                                                                            uint32 addr, 
                                                                            uint8 *dataReadPtr, 
                                                                            uint32 totalDataCount);
    CY_INLINE static Serial_FLASH_status Serial_FLASH_SpiNvCommand(uint8 nvramId, 
                                                                           uint32 nvcmd);
    CY_INLINE static Serial_FLASH_status Serial_FLASH_SpiSerialNoWrite(uint8 nvramId,
                                                                               const uint8 *dataPtr);
    CY_INLINE static Serial_FLASH_status Serial_FLASH_SpiSerialNoRead(uint8 nvramId,
                                                                              uint8 *dataPtr);
    CY_INLINE static Serial_FLASH_status Serial_FLASH_SpiDevIdRead(uint8 nvramId, 
                                                                           uint8 *dataPtr, 
                                                                           uint32 iDLength);
#endif

#if (Serial_FLASH_INTERFACE_I2C_SCB == Serial_FLASH_INTERFACE)
    static uint32 Serial_FLASH_I2cDataWrite(const uint8 dataWritePtr[], uint32 totalDataCount);
    static uint32 Serial_FLASH_I2cDataRead(uint8 dataReadPtr[], uint32 totalDataCount);
    static Serial_FLASH_status Serial_FLASH_I2CSendStop(uint32 i2cStatus);
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cMemoryWrite(uint8 nvramId, 
                                                                             uint32 addr, 
                                                                             const uint8 *dataWritePtr, 
                                                                             uint32 totalDataCount);
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cMemoryRead(uint8 nvramId, 
                                                                            uint32 addr, 
                                                                            uint8 *dataReadPtr, 
                                                                            uint32 totalDataCount);
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cRtcRegWrite(uint8 nvramId, 
                                                                             uint32 addr, 
                                                                             const uint8 *dataWritePtr, 
                                                                             uint32 totalDataCount);
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cRtcRegRead(uint8 nvramId, 
                                                                           uint32 addr, 
                                                                           uint8 *dataReadPtr, 
                                                                           uint32 totalDataCount);
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cNvCommand(uint8 nvramId, 
                                                                           uint32 nvcmd);
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cSerialNoWrite(uint8 nvramId,
                                                                               const uint8 *dataPtr);
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cSerialNoRead(uint8 nvramId,
                                                                              uint8 *dataPtr);
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cUniqueSleep(uint8 nvramId);
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cUniqueSerialNoRead(uint8 nvramId,
                                                                                    uint8 *dataPtr);
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cUniqueDevIdRead(uint8 nvramId,
                                                                                 uint8 *dataPtr,
                                                                                 uint32 iDLength);
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cDevIdRead(uint8 nvramId, 
                                                                           uint8 *dataPtr, 
                                                                           uint32 iDLength);
#endif

/** Serial_FLASH_initVar indicates whether the Serial_FLASH  component
*  has been initialized. The variable is initialized to 0 and set to 1 the first
*  time Serial_FLASH_Start() is called.
*  This allows the component to restart without reinitialization after the first 
*  call to the Serial_FLASH_Start() routine.
*
*  If re-initialization of the component is required, then the 
*  Serial_FLASH_Init() function can be called before the 
*  Serial_FLASH_Start() function.
*/
uint8 Serial_FLASH_initVar = 0u;


/*******************************************************************************
* Function Name:   Serial_FLASH_SetDefaultPins
****************************************************************************//**
*
*  Sets the control pins to the default state.
*
*******************************************************************************/
CY_INLINE static void Serial_FLASH_SetDefaultPins(void) 
{   
    #if (Serial_FLASH_INTERFACE_SPI_SCB == Serial_FLASH_INTERFACE)
        /* Disable the chip */
        Serial_FLASH_CS_0_OFF;
        #if (Serial_FLASH_CS1 < Serial_FLASH_SPI_CHIP_SELECT)
            Serial_FLASH_CS_1_OFF;
            #if (Serial_FLASH_CS2 < Serial_FLASH_SPI_CHIP_SELECT)
                Serial_FLASH_CS_2_OFF;
            #endif
                #if (Serial_FLASH_CS3 < Serial_FLASH_SPI_CHIP_SELECT)
                    Serial_FLASH_CS_3_OFF;
                #endif
        #endif
        #if (1 == Serial_FLASH_ENABLE_HOLD)
            Serial_FLASH_SetHold(Serial_FLASH_HIGH);
        #endif
        #if (1 == Serial_FLASH_ENABLE_WRITE_PROTECTION)
            Serial_FLASH_SetWp(Serial_FLASH_HIGH);
        #endif
    #endif

    #if (Serial_FLASH_INTERFACE_I2C_SCB == Serial_FLASH_INTERFACE)
        #if (1 == Serial_FLASH_ENABLE_WRITE_PROTECTION)
            Serial_FLASH_SetWp(Serial_FLASH_LOW);
        #endif
    #endif
}


/*******************************************************************************
* Function Name:   Serial_FLASH_Init
****************************************************************************//**
*
*  The initialization routine for the NVRAM component. 
*   Initializes the SPI/I2C block, CS, WP, and Hold configurations.
*
*******************************************************************************/
void Serial_FLASH_Init(void) 
{   
    /* Start the communication interface */
    Serial_FLASH_InterfaceStart();
    
    /* Init the pins (CS, HOLD, WP) */
    Serial_FLASH_SetDefaultPins();
}


/*******************************************************************************
* Function Name:   Serial_FLASH_Start
****************************************************************************//**
*
*  The start function, initializes the SerialNVRAM with the default values.
*
* \globalvars
*   Serial_FLASH_initVar: The global variable, defines if the component  
*                             will be initialized to the schematic state. 
*
*******************************************************************************/
void Serial_FLASH_Start(void) 
{
    if(0u == Serial_FLASH_initVar)      
    {
        Serial_FLASH_Init();
        Serial_FLASH_initVar = 1u;      
    }
}


/*******************************************************************************
* Function Name:   Serial_FLASH_Stop
****************************************************************************//**
*
* Disables the Serial NVRAM component but does not stop the
* Master component.
*
*******************************************************************************/
void Serial_FLASH_Stop(void) 
{
    Serial_FLASH_SetDefaultPins();
}


/*******************************************************************************
* Function Name:   Serial_FLASH_GetStatus
****************************************************************************//**
*
* Returns the external device ready/busy status after the initiated 
* transfer is complete.
*
*  \note The function always returns Serial_FLASH_SUCCESS for F-RAM devices.
*
*  \param nvramId: CS for SPI, the slave address for I2C. 
* The nvramId parameter for I2C devices have the following I2C slave 
* address:  0 1 0 1 0 A2 A1 A0. The three LSB bits are configurable 
* slave address inputs A2, A1, A0. Some I2C NVRAMs use three LSB bits 
* as memory page select to address higher density than addressable through 
* dedicated address byte (s) (one or two bytes) sent after the I2C command byte. 
* For example 4Kb and 16Kb I2C F-RAMs use A0 and A2, A1,A0 bits respectively 
* as page select bits followed by 1-byte memory address. 
* Similarly, 1Mb device use A0 as page select address bit followed by 
* 2-byte memory address.
* The I2C NVRAM devices internally ignore the page select bit setting and 
* always send an ACK during the command cycle. However, page select bits are 
* internally used to set the memory page address for the subsequent access. 
* For example: the CY14C101I device has Pin A2 connected to the high level 
* and Pin A1 connected to the ground. This corresponds to valid 
* nvramId = 0xA4 or 0xA5 with lower or upper page address set.
*
*  \return 
*  status:
*  * Serial_FLASH_SUCCESS - data is sent/received and the component is ready 
*     to send/receive new data
*  * Serial_FLASH_DEVICE_BUSY - the component is sending/receiving previous
*      data or the device error.
*
*******************************************************************************/
Serial_FLASH_status Serial_FLASH_GetStatus(uint8 nvramId) 
{
    Serial_FLASH_status status;

    #if (Serial_FLASH_INTERFACE_SPI_SCB == Serial_FLASH_INTERFACE)
        uint8 dataByte;

        status = Serial_FLASH_StatusRegRead(nvramId, &dataByte);
        if (Serial_FLASH_SUCCESS == status)
        {
            if (Serial_FLASH_SPI_NOT_RDY != (dataByte & Serial_FLASH_SPI_NOT_RDY))
            {
                status = Serial_FLASH_SUCCESS;
            }
            else
            {
                status = Serial_FLASH_DEVICE_BUSY;
            }
        }
        else
        {
            status = Serial_FLASH_DEVICE_BUSY;
        }    
        
    #endif

    #if (Serial_FLASH_INTERFACE_I2C_SCB == Serial_FLASH_INTERFACE)
        uint32 dataByte;
    
        /* Apply the mask to unused bits */
        nvramId = nvramId & Serial_FLASH_I2C_SLAVE_ADDR_MASK;
    
        /* Set the I2C Memory selection mask */
        nvramId = nvramId | Serial_FLASH_NVRAM_SEL_MEM_MASK;
    
        /*  Send the Start condition and slave ID for Write */
        dataByte = SPI_EXTMEM_I2CMasterSendStart((uint32)nvramId, 
                                                         SPI_EXTMEM_I2C_WRITE_XFER_MODE, 
                                                         Serial_FLASH_I2C_COM_TIMEOUT_MS);

        /* Send Stop */
        (void)SPI_EXTMEM_I2CMasterSendStop(Serial_FLASH_I2C_COM_TIMEOUT_MS);

        if (SPI_EXTMEM_I2C_MSTR_ERR_LB_NAK != dataByte)
        {
            status = Serial_FLASH_SUCCESS;
        }
        else
        {
            status = Serial_FLASH_DEVICE_BUSY;
        }   
    #endif

    return status;
}


/*******************************************************************************
* Function Name:   Serial_FLASH_MemoryWrite
****************************************************************************//**
*
* Writes the totalDataCount number of data into NVRAM.
*
*  \param nvramId: CS for SPI, the slave address for I2C.
*  For I2C devices see the detailed format in
*  Serial_FLASH_GetStatus() description.
*
*  \param addr: The 1/2/3-byte NVRAM address for Write.
*  \param *dataWritePtr: The pointer to an array of data bytes to be written.
*  \param totalDataCount: The number of data bytes to be written.
*
* \return
* Error status:
*  * Serial_FLASH_SUCCESS - No errors.
*  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
*  * Serial_FLASH_TIMEOUT_ERROR - The device does not 
*     respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
*
*******************************************************************************/
Serial_FLASH_status Serial_FLASH_MemoryWrite(uint8 nvramId, 
                                                     uint32 addr, 
                                                     const uint8 *dataWritePtr, 
                                                     uint32 totalDataCount) 
{
    Serial_FLASH_status status = Serial_FLASH_SUCCESS;

    CYASSERT(dataWritePtr); /* dataWritePtr cannot be NULL */

    #if (Serial_FLASH_INTERFACE_SPI_SCB == Serial_FLASH_INTERFACE)
        status = Serial_FLASH_SpiMemoryWrite(nvramId, 
                                                 addr, 
                                                 dataWritePtr, 
                                                 totalDataCount);
    #endif
    #if (Serial_FLASH_INTERFACE_I2C_SCB == Serial_FLASH_INTERFACE)
        status = Serial_FLASH_I2cMemoryWrite(nvramId, 
                                                 addr, 
                                                 dataWritePtr, 
                                                 totalDataCount);
    #endif

    return status;
}


/*******************************************************************************
* Function Name:   Serial_FLASH_MemoryRead
****************************************************************************//**
*
* Reads the totalDataCount number of data from NVRAM. 
*
*  \param nvramId: CS for SPI, the slave address for I2C.
*  For I2C devices see the detailed format in
*  Serial_FLASH_GetStatus() description.
*  \param addr: The 1/2/3-byte NVRAM address for Write.
*  \param *dataReadPtr: The pointer to an array for storing data bytes.
*  \param totalDataCount: The number of data bytes to be read.
*
* \return
* Error status:
*  * Serial_FLASH_SUCCESS - No errors.
*  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
*  * Serial_FLASH_TIMEOUT_ERROR - The device does not 
*     respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
*
*******************************************************************************/
Serial_FLASH_status Serial_FLASH_MemoryRead(uint8 nvramId, 
                                                    uint32 addr, 
                                                    uint8 *dataReadPtr, 
                                                    uint32 totalDataCount)
{
    Serial_FLASH_status status = Serial_FLASH_SUCCESS;

    CYASSERT(dataReadPtr); /* dataReadPtr cannot be NULL */

    #if (Serial_FLASH_INTERFACE_SPI_SCB == Serial_FLASH_INTERFACE)
        status = Serial_FLASH_SpiMemoryRead(nvramId, 
                                                addr, 
                                                dataReadPtr, 
                                                totalDataCount);
    #endif
    #if (Serial_FLASH_INTERFACE_I2C_SCB == Serial_FLASH_INTERFACE)
        status = Serial_FLASH_I2cMemoryRead(nvramId, 
                                                addr, 
                                                dataReadPtr, 
                                                totalDataCount);
    #endif

    return status;
}


#if (Serial_FLASH_INTERFACE_I2C_SCB == Serial_FLASH_INTERFACE)
    /*******************************************************************************
    * Function Name:   Serial_FLASH_CurrentMemoryRead
    ****************************************************************************//**
    *
    * Reads totalDataCount number of the data current address of I2C NVRAM. 
    *
    *  \param nvramId: The slave address for I2C.
    *  The nvramId parameter for I2C devices has the following format: 
    *  0 0 0 0 0 A2 A1 A0. The R/W bit is not used.
    *  Three LSB bits define the slave address inputs A2, A1 or A2, A1, and A0 bits
    *  for the I2C devices that have A2, A1, and A0 bits for the page select.  
    *  Bit A0 is the page select bit and it equals to 1 for address from 0x10000.
    *  For example: the CY14C101I device has Pin A2 connected to the high level 
    *  and Pin A1 connected to the ground. This corresponds to 
    *  valid 0x04 for reading data with the address below 0x10000 and
    *  nvramId = 0x05 for reading data with the address from 0x10000.
    *  \param *dataReadPtr: The pointer to an array for storing data bytes.
    *  \param totalDataCount: The number of data bytes to be read.
    *
    * \return 
    * error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_COMMUNICATION_ERROR - A Communication error.
    *
    *******************************************************************************/
    Serial_FLASH_status Serial_FLASH_CurrentMemoryRead(uint8 nvramId, 
                                                               uint8 *dataReadPtr, 
                                                               uint32 totalDataCount)
    {
        uint32 i2cStatus;
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;
 
        CYASSERT(dataReadPtr); /* dataReadPtr cannot be NULL */

        /* Apply the mask to unused bits */
        nvramId = nvramId & Serial_FLASH_I2C_SLAVE_ADDR_MASK;
        
        /* Set the I2C Memory selection mask */
        nvramId = nvramId | Serial_FLASH_NVRAM_SEL_MEM_MASK;
        
        /* Send the Start condition and slave ID for Read */
        i2cStatus = SPI_EXTMEM_I2CMasterSendStart((uint32)nvramId, 
                                                          SPI_EXTMEM_I2C_READ_XFER_MODE, 
                                                          Serial_FLASH_I2C_COM_TIMEOUT_MS);

        /* Read data from the slave */
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Read the array of the totalDataCount bytes */
            i2cStatus = Serial_FLASH_I2cDataRead(dataReadPtr, totalDataCount);
        }
        
        /* Send Stop and get the error status */
        status = Serial_FLASH_I2CSendStop(i2cStatus);

        return status;
    }
#endif


#if (Serial_FLASH_INTERFACE_SPI_SCB == Serial_FLASH_INTERFACE)
    /*******************************************************************************
    * Function Name:   Serial_FLASH_MemoryFastReadOpcode
    ****************************************************************************//**
    *
    * Reads the totalDataCount number of data from SPI NVRAM using
    * the Fast Read command.
    *
    *  \param nvramId: CS for SPI
    *  \param addr: The 1/2/3-byte NVRAM address for Write.
    *  \param *dataReadPtr: The pointer to an array for storing data bytes.
    *  \param totalDataCount: The number of data bytes to be read.
    *
    * \return 
    * Error status:
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does not 
    *     respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    Serial_FLASH_status Serial_FLASH_MemoryFastReadOpcode(uint8 nvramId, 
                                                                  uint32 addr, 
                                                                  uint8 *dataReadPtr, 
                                                                  uint32 totalDataCount)
    {
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        CYASSERT(dataReadPtr); /* dataReadPtr cannot be NULL */

        /* Select the F-RAM device */
        status = Serial_FLASH_SpiSelectDevice(nvramId);
        
        if (Serial_FLASH_SUCCESS == status)
        {
            /* Send the F-RAM Fast Read command */
            SPI_EXTMEM_SpiUartWriteTxData(Serial_FLASH_NVRAM_SRAM_FAST_READ_CMD);   
            
            /* For densities greater than or equal to 1MBit, send a 3-byte address */
            #if (Serial_FLASH_DENSITY_1_MBIT <= Serial_FLASH_DENSITY)
                SPI_EXTMEM_SpiUartWriteTxData((addr & Serial_FLASH_MSB_ADDR_MASK)>>Serial_FLASH_MSB_ADDR_SHIFTBITS);
            #endif
        
            /* Send a 2-byte address */
            SPI_EXTMEM_SpiUartWriteTxData((addr & Serial_FLASH_ISB_ADDR_MASK)>>Serial_FLASH_ISB_ADDR_SHIFTBITS);
            SPI_EXTMEM_SpiUartWriteTxData(addr);
        
            /* Wait for the transmission to complete */
            status = Serial_FLASH_SpiTxBusyCheck();
            
            if (Serial_FLASH_SUCCESS == status)
            {
                /* Send the dummy byte to start receiving data */
                SPI_EXTMEM_SpiUartWriteTxData(Serial_FLASH_DUMMY_BYTE);
                
                /* Read the data bytes */
                status = Serial_FLASH_SpiBufferRead(dataReadPtr, totalDataCount);
            }
            
            /* De-select the F-RAM device  */
            (void)Serial_FLASH_SpiDeSelectDevice(nvramId);
        }

        return status;
    }

        
    /*******************************************************************************
    * Function Name:   Serial_FLASH_StatusRegWrite
    ****************************************************************************//**
    *
    * Writes the NVRAM Status register.
    *
    *  \param nvramId: CS for SPI.
    *  \param dataByte: The 1-byte status register data to be written.
    *
    * \return
    * Error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does not 
    *     respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    Serial_FLASH_status Serial_FLASH_StatusRegWrite(uint8 nvramId, uint8 dataByte)
    {
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        /* Send the WREN command */
        status = Serial_FLASH_SpiSetWriteEnable(nvramId);

        if (Serial_FLASH_SUCCESS == status)
        {
            /* Select the F-RAM device */
            (void)Serial_FLASH_SpiSelectDevice(nvramId);

            /* Send Write Status Register command */
            SPI_EXTMEM_SpiUartWriteTxData(Serial_FLASH_NVRAM_WRSR_CMD);

            /* Send the status register data */
            SPI_EXTMEM_SpiUartWriteTxData((uint32)dataByte);
            
            /* Wait for the transmission to complete */
            status = Serial_FLASH_SpiTxBusyCheck();

            /* De-select the F-RAM device  */
            (void)Serial_FLASH_SpiDeSelectDevice(nvramId);
        }

        return status;
    }


    /*******************************************************************************
    * Function Name:   Serial_FLASH_StatusRegRead
    ****************************************************************************//**
    *
    * Reads the NVRAM Status register. 
    *
    *  \param nvramId: CS for SPI.
    *  \param *dataByte: The pointer to the holding status register value.
    *
    * \return
    * Error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does not 
    *     respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    Serial_FLASH_status Serial_FLASH_StatusRegRead(uint8 nvramId, uint8 *dataByte)
    {
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        /* Clear the receive buffer */
        SPI_EXTMEM_SpiUartClearRxBuffer();

        /* Select the F-RAM device */
        status = Serial_FLASH_SpiSelectDevice(nvramId);

        if (Serial_FLASH_SUCCESS == status)
        {
            /* Send the status register Read command */
            SPI_EXTMEM_SpiUartWriteTxData(Serial_FLASH_NVRAM_RDSR_CMD);

            /* Send the dummy byte to receive data */
            SPI_EXTMEM_SpiUartWriteTxData(0x00U);

            /* Wait for the transmission to complete */
            status = Serial_FLASH_SpiTxBusyCheck();
        
            if (Serial_FLASH_SUCCESS == status)
            {
                /* Ensure data is received in the receive buffer */
                status = Serial_FLASH_SpiRxBufferCheck();
                
                /* Read the buffer twice because the second byte received 
                   is the status reg data 
                */
                *dataByte = (uint8)SPI_EXTMEM_SpiUartReadRxData(); 
                *dataByte = (uint8)SPI_EXTMEM_SpiUartReadRxData();
            }

            /* De-select the F-RAM device  */
            (void)Serial_FLASH_SpiDeSelectDevice(nvramId);
        }

        return status;
    }

    
    /*******************************************************************************
    * Function Name:   Serial_FLASH_WriteProcessorCompanion
    ****************************************************************************//**
    *
    * Writes the SPI F-RAM processor companion register. 
    * This function is applicable for the devices which support WRPC and RDPC. 
    * Refer to the device datasheet for details.
    *
    *  \note To write the RTC register of the companion device, this function 
    *  should set the W bit of the RTC/Alarm Control register
    *  (Serial_FLASH_COMPANION_RTC_ALARM_CTL) and then write the RTC register.
    *  For example, the following code updates the Day register with value = 4:
    *  Serial_FLASH_status status;
    *  uint8 writeCommand = 2u;
    *  uint8 day = 4u;
    *  status = Serial_FLASH_WriteProcessorCompanion(Serial_FLASH_CS0,
    *                             Serial_FLASH_COMPANION_RTC_ALARM_CTL, 
    *                             &writeCommand, 1u);
    *  status = Serial_FLASH_WriteProcessorCompanion(Serial_FLASH_CS0,
    *                             Serial_FLASH_COMPANION_DAY_01_07, 
    *                             &day, 1u);
    *
    *  \param nvramId: CS for SPI.
    *  \param addr: The 8-bit F-RAM Processor companion
    *  register address for Write.
    *  \param *dataPtr: The pointer to an array of data to be written.
    *  \param totalDataCount: The number of data bytes to be written.
    *
    * \return
    * Error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does
    *     not respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    Serial_FLASH_status Serial_FLASH_WriteProcessorCompanion(uint8 nvramId,
                                                                     uint32 addr,
                                                                     const uint8 *dataPtr,
                                                                     uint32 totalDataCount)
    {
        Serial_FLASH_status status;

        /* Send the WREN command */
        status = Serial_FLASH_SpiSetWriteEnable(nvramId);
        
        if (Serial_FLASH_SUCCESS == status)
        {
            /* Select the F-RAM device */
            (void)Serial_FLASH_SpiSelectDevice(nvramId);

            /* Send the processor companion register Write command */
            SPI_EXTMEM_SpiUartWriteTxData(Serial_FLASH_NVRAM_WRPC_CMD);
            
            /* Send 1 register address byte */
            SPI_EXTMEM_SpiUartWriteTxData(addr);
            
            /* Send the processor companion register */
            status = Serial_FLASH_SpiBufferWrite(dataPtr, totalDataCount);

            /* De-select the F-RAM device  */
            (void)Serial_FLASH_SpiDeSelectDevice(nvramId); 
        }

        return status;
    }
    
    
    /*******************************************************************************
    * Function Name:   Serial_FLASH_ReadProcessorCompanion
    ****************************************************************************//**
    *
    * Reads the SPI F-RAM processor companion register. 
    * This function is applicable for the devices which support WRPC and RDPC. 
    * Refer to the device datasheet for details.
    *
    *  \note To read the data from the RTC register of the companion device, 
    *  this function should set the R bit of the RTC/Alarm Control register
    *  (Serial_FLASH_COMPANION_RTC_ALARM_CTL) and then read the RTC register.
    *  For example, the following code reads the Day register:
    *  Serial_FLASH_status status;
    *  uint8 readCommand = 1u;
    *  uint8 day = 4u;
    *  status = Serial_FLASH_WriteProcessorCompanion(Serial_FLASH_CS0, 
    *                             Serial_FLASH_COMPANION_RTC_ALARM_CTL, 
    *                             &readCommand, 1u);
    *  status = Serial_FLASH_ReadProcessorCompanion(Serial_FLASH_CS0, 
    *                             Serial_FLASH_COMPANION_DAY_01_07,
    *                             &day, 1u);
    *
    *  \param nvramId: CS for SPI.
    *  \param addr: The 8-bit F-RAM Processor companion
    *  register address for Read.
    *  \param *dataReadPtr: The pointer to an array for storing data bytes.
    *  \param totalDataCount: The number of data bytes to be read.
    *
    * \return 
    * Error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does 
    *     not respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    Serial_FLASH_status Serial_FLASH_ReadProcessorCompanion(uint8 nvramId,
                                                                    uint32 addr,
                                                                    uint8 *dataReadPtr,
                                                                    uint32 totalDataCount)
    {
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        /* Select the F-RAM device */
        status = Serial_FLASH_SpiSelectDevice(nvramId);

        if (Serial_FLASH_SUCCESS == status)
        {
            /* Send the F-RAM processor companion register Read command */
            SPI_EXTMEM_SpiUartWriteTxData(Serial_FLASH_NVRAM_RDPC_CMD);   
        
            /* Send 1 address byte */
            SPI_EXTMEM_SpiUartWriteTxData(addr);
        
            /* Read the data bytes */
            status = Serial_FLASH_SpiBufferRead(dataReadPtr, totalDataCount);
            
            /* De-select the F-RAM device  */
            (void)Serial_FLASH_SpiDeSelectDevice(nvramId);
        }

        return status;
    }
#endif


#if (Serial_FLASH_INTERFACE_I2C_SCB == Serial_FLASH_INTERFACE)
    /*******************************************************************************
    * Function Name:   Serial_FLASH_MemCtrlRegWrite
    ****************************************************************************//**
    *
    * Writes to NVRAM Memory Control Register.    
    *
    *  \param nvramId: The slave address for I2C.
    *  For I2C devices see the detailed format in
    *  Serial_FLASH_GetStatus() description.
    *  \param dataByte: The 1-byte Memory Control register data to be written.
    *
    * \return 
    * Error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does not 
    *     respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    Serial_FLASH_status Serial_FLASH_MemCtrlRegWrite(uint8 nvramId, uint8 dataByte)
    {
        uint32 i2cStatus;
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        /* Apply the mask to unused bits */
        nvramId = nvramId & Serial_FLASH_I2C_SLAVE_ADDR_MASK; 
        
        /* Set the Control Registers Slave Address */
        nvramId = nvramId | Serial_FLASH_NVRAM_SEL_CR_MASK;

        /*  Send the Start condition and slave ID for Write */
        i2cStatus = SPI_EXTMEM_I2CMasterSendStart((uint32)nvramId,
                                                       SPI_EXTMEM_I2C_WRITE_XFER_MODE, 
                                                       Serial_FLASH_I2C_COM_TIMEOUT_MS);
        
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the Memory Control Register address byte */
            i2cStatus = SPI_EXTMEM_I2CMasterWriteByte(Serial_FLASH_MEM_CTR_REG_ADDR, 
                                                              Serial_FLASH_I2C_COM_TIMEOUT_MS);
        
            if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
            {
               /* Send the data byte for Write */
               i2cStatus = SPI_EXTMEM_I2CMasterWriteByte((uint32)dataByte, 
                                                                 Serial_FLASH_I2C_COM_TIMEOUT_MS);
            }
        }

        /* Send Stop and get the error status */
        status = Serial_FLASH_I2CSendStop(i2cStatus); 

        return status;
    }


    /*******************************************************************************
    * Function Name:   Serial_FLASH_MemCtrlRegRead
    ****************************************************************************//**
    *
    * Reads the NVRAM Memory Control Register content.  
    *
    *  \param nvramId: The slave address for I2C.
    *  For I2C devices see the detailed format in
    *  Serial_FLASH_GetStatus() description.
    *  \param *dataByte: The pointer for holding the Control register value.
    *
    * \return 
    * error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_COMMUNICATION_ERROR - A communication error.
    *
    *******************************************************************************/
    Serial_FLASH_status Serial_FLASH_MemCtrlRegRead(uint8 nvramId, uint8 *dataByte)
    {
        uint32 i2cStatus;
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        /* Apply the mask to unused bits */
        nvramId = nvramId & Serial_FLASH_I2C_SLAVE_ADDR_MASK; 
        
        /* Set the Control Registers Slave Address */
        nvramId = nvramId | Serial_FLASH_NVRAM_SEL_CR_MASK;

        /* Send the Start condition and slave ID for Write */
        i2cStatus = SPI_EXTMEM_I2CMasterSendStart((uint32)nvramId, 
                                                          SPI_EXTMEM_I2C_WRITE_XFER_MODE, 
                                                          Serial_FLASH_I2C_COM_TIMEOUT_MS);
        
        /* Write the the Memory Control Register address to the slave */
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the address byte */
            i2cStatus = SPI_EXTMEM_I2CMasterWriteByte(Serial_FLASH_MEM_CTR_REG_ADDR, 
                                                              Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }

        /* Read data from the slave */
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the ReStart condition and slave ID for Read */
            i2cStatus = SPI_EXTMEM_I2CMasterSendRestart((uint32)nvramId, 
                                                                SPI_EXTMEM_I2C_READ_XFER_MODE, 
                                                                Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }

        /* Read the byte with NAK data */
        i2cStatus = SPI_EXTMEM_I2CMasterReadByte(SPI_EXTMEM_I2C_NAK_DATA, 
                                                         dataByte, 
                                                         Serial_FLASH_I2C_COM_TIMEOUT_MS);
        
        /* Send Stop and get the error status */
        status = Serial_FLASH_I2CSendStop(i2cStatus); 

        return status;
    }
#endif


/*******************************************************************************
* Function Name:   Serial_FLASH_Sleep
****************************************************************************//**
*
* Sends the NVRAM command for sleep.
*
*  \param nvramId: CS for SPI, the slave address for I2C.
*  For I2C devices see the detailed format in
*  Serial_FLASH_GetStatus() description.
*  The nvramId parameter for the FM24VN10 families has the following I2C slave
*  address format: 0 1 0 1 0 A2 A1 A16. 
*  Bits A2 and A1 are the slave address inputs. 
*  Bit A16 is the page select bit and it can have any value for this function. 
*  Four FM24VN10 devices can be connected to I2C bus with the following
*  nvramId parameter values:
*  * 0x50 - Both A2 and A1 pins are connected to the ground.
*  * 0x52 - Pin A2 connected to the ground and Pin A1 connected to the high level.
*  * 0x54 - Pin A2 connected to the high level and Pin A1 connected to the ground.
*  * 0x56 – Both A2 and A1 pins are connected to the high level.
*
* \return 
* Error status
*  * Serial_FLASH_SUCCESS - No errors.
*  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
*  * Serial_FLASH_TIMEOUT_ERROR - The device does not 
*     respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
*
*******************************************************************************/
Serial_FLASH_status Serial_FLASH_Sleep(uint8 nvramId)
{
    Serial_FLASH_status status = Serial_FLASH_SUCCESS;

    #if (Serial_FLASH_INTERFACE_SPI_SCB == Serial_FLASH_INTERFACE)
        status =  Serial_FLASH_NvCommand(nvramId, Serial_FLASH_NVRAM_SLEEP_CMD);
    #endif
    #if (Serial_FLASH_INTERFACE_I2C_SCB == Serial_FLASH_INTERFACE)
        /* Check if the device is FM24V10 */
        if (Serial_FLASH_I2C_FM24V10_SLAVE_ID == (Serial_FLASH_I2C_FM24V10_SLAVE_ID & nvramId))
        {
            status = Serial_FLASH_I2cUniqueSleep(nvramId);
        }
        else
        {
            status = Serial_FLASH_I2cNvCommand(nvramId, Serial_FLASH_NVRAM_SLEEP_CMD);
        }  
    #endif

    return status;
}


/*******************************************************************************
* Function Name:   Serial_FLASH_NvCommand
****************************************************************************//**
*
* Sends the NVRAM command. This is supported by nvSRAM only. 
*
*  \param nvramId: CS for SPI, the slave address for I2C.
*  For I2C devices see the detailed format in
*  Serial_FLASH_GetStatus() description.
*  \param nvcmd: The 8-bit NVRAM command.
*
* \return 
* Error status
*  * Serial_FLASH_SUCCESS - No errors.
*  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
*  * Serial_FLASH_TIMEOUT_ERROR - The device does not 
*     respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
*
*******************************************************************************/
Serial_FLASH_status Serial_FLASH_NvCommand(uint8 nvramId, uint8 nvcmd)
{
    Serial_FLASH_status status = Serial_FLASH_SUCCESS;

    #if (Serial_FLASH_INTERFACE_SPI_SCB == Serial_FLASH_INTERFACE)
        status = Serial_FLASH_SpiNvCommand(nvramId, (uint32)nvcmd);
    #endif
    #if (Serial_FLASH_INTERFACE_I2C_SCB == Serial_FLASH_INTERFACE)
        status = Serial_FLASH_I2cNvCommand(nvramId, (uint32)nvcmd);
    #endif

    return status;
}


/*******************************************************************************
* Function Name:   Serial_FLASH_SerialNoWrite
****************************************************************************//**
*
* Writes the NVRAM Serial number. 
*
*  \param nvramId: CS for SPI, the slave address for I2C.
*  For I2C devices see the detailed format in
*  Serial_FLASH_GetStatus() description.
*
*  \note This function is applicable for devices with a serial number in the 
*  Control registers map. 
*  The Serial_FLASH_RtcRegWrite()/Serial_FLASH_WriteProcessorCompanion() 
*  functions are used for devices with a serial number in the RTC / processor 
*  companion register map. For more detail, refer to the device datasheet.
*
*  \param *dataPtr: The pointer to an array of the serial number
*  data to be written.
*
* \return
* Error status
*  * Serial_FLASH_SUCCESS - No errors.
*  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
*  * Serial_FLASH_TIMEOUT_ERROR - The device does not 
*     respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
*
*******************************************************************************/
Serial_FLASH_status Serial_FLASH_SerialNoWrite(uint8 nvramId, const uint8 *dataPtr)
{
    Serial_FLASH_status status = Serial_FLASH_SUCCESS;

    CYASSERT(dataPtr); /* dataPtr cannot be NULL */

    #if (Serial_FLASH_INTERFACE_SPI_SCB == Serial_FLASH_INTERFACE)
        status = Serial_FLASH_SpiSerialNoWrite(nvramId, dataPtr);
    #endif
    #if (Serial_FLASH_INTERFACE_I2C_SCB == Serial_FLASH_INTERFACE)
        status = Serial_FLASH_I2cSerialNoWrite(nvramId, dataPtr);
    #endif

    return status;
}


/*******************************************************************************
* Function Name:   Serial_FLASH_SerialNoRead
****************************************************************************//**
*
* Reads the NVRAM Serial number.
*
*  \param nvramId: CS for SPI, the slave address for I2C.
*  For I2C devices see the detailed format in
*  Serial_FLASH_GetStatus() description.
*  The nvramId parameter for the FM24VN10 families has the following
*  I2C slave address  format: 0 1 0 1 0 A2 A1 A16. 
*  Bits A2 and A1 are the slave address inputs. 
*  Bit A16 is the page select bit and it can have any value for this function. 
*  Four FM24VN10 devices can be connected to I2C bus with the following
*  nvramId parameter values:
*  * 0x50 - Both A2 and A1 pins are connected to the ground.
*  * 0x52 - Pin A2 connected to the ground and Pin A1 connected to the high level.
*  * 0x54 - Pin A2 connected to the high level and Pin A1 connected to the ground.
*  * 0x56 – Both A2 and A1 pins are connected to the high level.
*
*  \note This function is not applicable for devices with a serial number in 
*  RTC / processor companion register map.
*  The Serial_FLASH_RtcRegRead()/Serial_FLASH_ReadProcessorCompanion() 
*  functions are used for devices with a serial number in the RTC / processor 
*  companion register map. For more detail, refer to the device datasheet.
*
*  \param *dataPtr: The pointer to an array for storing serial number data.
*
* \return 
* Error status
*  * Serial_FLASH_SUCCESS - No errors.
*  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
*  * Serial_FLASH_TIMEOUT_ERROR - The device does not 
*     respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
*
*******************************************************************************/
Serial_FLASH_status Serial_FLASH_SerialNoRead(uint8 nvramId, uint8 *dataPtr)
{
    Serial_FLASH_status status = Serial_FLASH_SUCCESS;

    CYASSERT(dataPtr); /* dataPtr cannot be NULL */

    #if (Serial_FLASH_INTERFACE_SPI_SCB == Serial_FLASH_INTERFACE)
        status = Serial_FLASH_SpiSerialNoRead(nvramId, dataPtr);
    #endif
    #if (Serial_FLASH_INTERFACE_I2C_SCB == Serial_FLASH_INTERFACE)
        /* Check if the device is FM24V10 */
        if (Serial_FLASH_I2C_FM24V10_SLAVE_ID == (Serial_FLASH_I2C_FM24V10_SLAVE_ID & nvramId))
        {
            status = Serial_FLASH_I2cUniqueSerialNoRead(nvramId, dataPtr);
        }
        else
        {
            status = Serial_FLASH_I2cSerialNoRead(nvramId, dataPtr);  
        }
    #endif

    return status;
}


/*******************************************************************************
* Function Name:   Serial_FLASH_DevIdRead
****************************************************************************//**
*
* Reads the NVRAM device ID. This is supported by nvSRAM and F-RAM above 128Kbit.
* A pre-defined ID length covers the following varying device's IDs across
* different product families: 
*  * CY14B101PA - The DevID size is 4 bytes
*  * FM25VN10   - The DevID size is 9 bytes
*  * CY15B104Q  - The DevID size is 9 bytes
*  * CY14B101I  - The DevID size is 4 bytes
*  * FM24VN10   - The DevID size is 3 bytes
*  * FM31L278   - The DevID size is 8 bytes
*
*  \param nvramId: CS for SPI, the slave address for I2C.
*  For I2C devices see the detailed format in
*  Serial_FLASH_GetStatus() description.
*  The nvramId parameter for the FM24VN10 families has the I2C slave address  
*  following format: 0 1 0 1 0 A2 A1 A16. 
*  Bits A2 and A1 are the slave address inputs. 
*  Bit A16 is the page select bit and it can have any value for this function. 
*  Four FM24VN10 devices can be connected to I2C bus with the following
*  nvramId parameter values:
*  * 0x50 - Both A2 and A1 pins are connected to the ground.
*  * 0x52 - Pin A2 connected to the ground and Pin A1 connected to the high level.
*  * 0x54 - Pin A2 connected to the high level and Pin A1 connected to the ground.
*  * 0x56 – Both A2 and A1 pins are connected to the high level.

*  \param *dataPtr: The pointer to an array for storing the device ID.
*  \param IDLength: The four predefines for the ID length (3ByteDeviceID, 
*         4ByteDeviceID, 8ByteDeviceID, 9ByteDeviceID).
*
* \return 
* Error status
*  * Serial_FLASH_SUCCESS - No errors.
*  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
*  * Serial_FLASH_TIMEOUT_ERROR - The device does not 
*     respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
*
*******************************************************************************/
Serial_FLASH_status Serial_FLASH_DevIdRead(uint8 nvramId, uint8 *dataPtr, uint8 iDLength)
{
    Serial_FLASH_status status = Serial_FLASH_SUCCESS;

    CYASSERT(dataPtr); /* dataPtr cannot be NULL */

    #if (Serial_FLASH_INTERFACE_SPI_SCB == Serial_FLASH_INTERFACE)
        status = Serial_FLASH_SpiDevIdRead(nvramId, dataPtr, (uint32)iDLength);
    #endif
    #if (Serial_FLASH_INTERFACE_I2C_SCB == Serial_FLASH_INTERFACE)
        /* Check if the device is FM24V10 */
        if (Serial_FLASH_I2C_FM24V10_SLAVE_ID == (Serial_FLASH_I2C_FM24V10_SLAVE_ID & nvramId))
        {
            status = Serial_FLASH_I2cUniqueDevIdRead(nvramId, dataPtr, (uint32)iDLength);
        }
        else
        {
            status = Serial_FLASH_I2cDevIdRead(nvramId, dataPtr, (uint32)iDLength); 
        }
    #endif

    return status;
}


/*******************************************************************************
* Function Name:   Serial_FLASH_RtcRegWrite
****************************************************************************//**
*
* Writes the totalDataCount number of data into NVRAM RTC / F-RAM 
* Processor Companion registers. 
*
*  \note To write the RTC register, this function 
*  should set the W bit of the Flags register
*  (Serial_FLASH_RTC_FLAGS) and then write the RTC register.
*
*  \param nvramId: CS for SPI, the slave address for I2C.
*  For I2C devices see the detailed format in
*  Serial_FLASH_GetStatus() description.
*  \param addr: The 8-bit NVRAM RTC / F-RAM Proc companion register
*   address for Write.
*  \param *dataWritePtr: The pointer to an array of RTC data bytes to be written.
*  \param totalDataCount: The number of RTC data bytes to be written.
*
* \return 
* Error status
*  * Serial_FLASH_SUCCESS - No errors.
*  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
*  * Serial_FLASH_TIMEOUT_ERROR - The device does not 
*     respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
*
*******************************************************************************/
Serial_FLASH_status Serial_FLASH_RtcRegWrite(uint8 nvramId, 
                                                     uint32 addr, 
                                                     const uint8 *dataWritePtr, 
                                                     uint32 totalDataCount)
{
    Serial_FLASH_status status = Serial_FLASH_SUCCESS;

    CYASSERT(dataWritePtr); /* dataWritePtr cannot be NULL */

    #if (Serial_FLASH_INTERFACE_SPI_SCB == Serial_FLASH_INTERFACE)
        status = Serial_FLASH_SpiRtcRegWrite(nvramId, 
                                                 addr, 
                                                 dataWritePtr, 
                                                 totalDataCount);
    #endif
    #if (Serial_FLASH_INTERFACE_I2C_SCB == Serial_FLASH_INTERFACE)
        status = Serial_FLASH_I2cRtcRegWrite(nvramId, 
                                                 addr, 
                                                 dataWritePtr, 
                                                 totalDataCount);
    #endif

    return status;
}


/*******************************************************************************
* Function Name:   Serial_FLASH_RtcRegRead
****************************************************************************//**
*
* Reads the totalDataCount number of data from nvSRAM RTC / F-RAM Processor 
* Companion registers. 
*
*  \note To read the data from the RTC register of the companion device, 
*  this function should set the R bit of the Flags register
*  (Serial_FLASH_RTC_FLAGS) and then read the RTC register.
*
*  \param nvramId: CS for SPI, the slave address for I2C
*  For I2C devices see the detailed format in
*  Serial_FLASH_GetStatus() description.
*  \param addr: The 8-bit nvSRAM RTC / F-RAM Proc companion
*  register address for read.
*  \param *dataReadPtr: The pointer to an array for storing RTC data bytes.
*  \param totalDataCount: The number of RTC data bytes to be read.
*
* \return 
* Error status
*  * Serial_FLASH_SUCCESS - No errors.
*  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
*  * Serial_FLASH_TIMEOUT_ERROR - The device does not 
*     respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
*
*******************************************************************************/
Serial_FLASH_status Serial_FLASH_RtcRegRead(uint8 nvramId, 
                                    uint32 addr, 
                                    uint8 *dataReadPtr, 
                                    uint32 totalDataCount)
{
    Serial_FLASH_status status = Serial_FLASH_SUCCESS;

    CYASSERT(dataReadPtr); /* dataReadPtr cannot be NULL */

    #if (Serial_FLASH_INTERFACE_SPI_SCB == Serial_FLASH_INTERFACE)
        status = Serial_FLASH_SpiRtcRegRead(nvramId, 
                                                addr, 
                                                dataReadPtr, 
                                                totalDataCount);
    #endif
    #if (Serial_FLASH_INTERFACE_I2C_SCB == Serial_FLASH_INTERFACE)
        status = Serial_FLASH_I2cRtcRegRead(nvramId, 
                                                addr, 
                                                dataReadPtr, 
                                                totalDataCount);
    #endif

    return status;
}


#if (Serial_FLASH_INTERFACE_I2C_SCB == Serial_FLASH_INTERFACE)
    /*******************************************************************************
    * Function Name:   Serial_FLASH_CurrentRtcRegRead
    ****************************************************************************//**
    *
    * Reads the current totalDataCount number of data from nvSRAM RTC / F-RAM 
    * Processor Companion registers. 
    *
    *  \param nvramId: The slave address for I2C.
    *  For I2C devices see the detailed format in
    *  Serial_FLASH_GetStatus() description.
    *  \param *dataReadPtr: The pointer to an array for storing RTC data bytes. 
    *  \param totalDataCount: The number of RTC data bytes to be read.
    *
    * \return 
    * error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_COMMUNICATION_ERROR - A communication error.
    *
    *******************************************************************************/
    Serial_FLASH_status Serial_FLASH_CurrentRtcRegRead(uint8 nvramId, 
                                                               uint8 *dataReadPtr, 
                                                               uint32 totalDataCount)
    {       
        uint32 i2cStatus;
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;
 
        CYASSERT(dataReadPtr); /* dataReadPtr cannot be NULL */
 
        /* Apply the mask to unused bits */
        nvramId = nvramId & Serial_FLASH_I2C_SLAVE_ADDR_MASK;

        /* Set the RTC Registers selection mask */
        nvramId = nvramId | Serial_FLASH_NVRAM_SEL_RTCR_MASK;    

        /* Send the Start condition and slave ID for Read */
        i2cStatus = SPI_EXTMEM_I2CMasterSendStart((uint32)nvramId, 
                                                          SPI_EXTMEM_I2C_READ_XFER_MODE, 
                                                          Serial_FLASH_I2C_COM_TIMEOUT_MS);

         /* Read data from the slave */
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Read the array of the totalDataCount bytes */
            i2cStatus = Serial_FLASH_I2cDataRead(dataReadPtr, totalDataCount);
        }
       
        /* Send Stop and get the error status */
        status = Serial_FLASH_I2CSendStop(i2cStatus);

        return status;
    }
#endif


#if (1 == Serial_FLASH_ENABLE_WRITE_PROTECTION)
    /*******************************************************************************
    * Function Name:   Serial_FLASH_SetWp
    ****************************************************************************//**
    *
    * Sets the WP pin to HIGH or LOW.
    *
    *  \param value:  HIGH (1), LOW (0). 
    *
    *  \note
    *  The Active LOW level for SPI NVRAM and Active HIGH level for I2C NVRAM
    *  prevent write operation to the memory and the Status register. Refer to 
    *  the device datasheet for the choices about the software and hardware write 
    *  protection.    
    *******************************************************************************/
    void Serial_FLASH_SetWp(uint8 value)
    {
        Serial_FLASH_WP_Write(value);
    }
#endif


#if ((Serial_FLASH_INTERFACE_SPI_SCB == Serial_FLASH_INTERFACE) &&\
    (1 == Serial_FLASH_ENABLE_HOLD))
    /*******************************************************************************
    * Function Name:   Serial_FLASH_SetHold
    ****************************************************************************//**
    *
    * Sets the HOLD pin to HIGH or LOW.
    *
    *  \param value:  Serial_FLASH_HIGH (1), Serial_FLASH_LOW (0). 
    *
    *******************************************************************************/
    void Serial_FLASH_SetHold(uint8 value)
    {
        Serial_FLASH_HOLD_Write(value);
    }
#endif


#if (Serial_FLASH_INTERFACE_SPI_SCB == Serial_FLASH_INTERFACE)
    /*******************************************************************************
    * Function Name:   Serial_FLASH_SpiSelectDevice
    ****************************************************************************//**
    *
    * Sets the CS pin to the low state for a device with an SPI interface.
    *
    *  \param nvramId: CS for SPI
    * * Serial_FLASH_CS0 - The SPI device connected to the CS_0 pin.
    * * Serial_FLASH_CS1 - The SPI device connected to the CS_1 pin.
    * * Serial_FLASH_CS2 - The SPI device connected to the CS_2 pin.
    * * Serial_FLASH_CS3 - The SPI device connected to the CS_3 pin.
    *
    * \return
    *  error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *
    *******************************************************************************/
    static Serial_FLASH_status Serial_FLASH_SpiSelectDevice(uint8 nvramId)
    {
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        switch(nvramId)
        {
            case Serial_FLASH_CS0:
            {
                Serial_FLASH_CS_0_ON;
                break;
            }
            case Serial_FLASH_CS1:
            {
                #if (Serial_FLASH_CS1 < Serial_FLASH_SPI_CHIP_SELECT)
                    Serial_FLASH_CS_1_ON;
                #else
                    status = Serial_FLASH_DEVICE_ERROR;
                #endif
                break;
            }
            case Serial_FLASH_CS2:
            {
                #if (Serial_FLASH_CS2 < Serial_FLASH_SPI_CHIP_SELECT)
                    Serial_FLASH_CS_2_ON;
                #else
                    status = Serial_FLASH_DEVICE_ERROR;
                #endif
                break;
            }
            case Serial_FLASH_CS3:
            {
                #if (Serial_FLASH_CS3 < Serial_FLASH_SPI_CHIP_SELECT)
                    Serial_FLASH_CS_3_ON;
                #else
                    status = Serial_FLASH_DEVICE_ERROR;
                #endif
                break;
            }
            default:
            {
                status = Serial_FLASH_DEVICE_ERROR;
                break;
            }
        }

        return status;
    }


    /*******************************************************************************
    * Function Name:   Serial_FLASH_SpiDeSelectDevice
    ****************************************************************************//**
    *
    * Sets the CS pin to the high state for a device with an SPI interface.
    *
    *  \param nvramId: CS for SPI
    * * Serial_FLASH_CS0 - The SPI device connected to the CS_0 pin.
    * * Serial_FLASH_CS1 - The SPI device connected to the CS_1 pin.
    * * Serial_FLASH_CS2 - The SPI device connected to the CS_2 pin.
    * * Serial_FLASH_CS3 - The SPI device connected to the CS_3 pin.
    *
    * \return
    *  error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *
    *******************************************************************************/
    static Serial_FLASH_status Serial_FLASH_SpiDeSelectDevice(uint8 nvramId)
    {
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        switch(nvramId)
        {
            case Serial_FLASH_CS0:
            {
                Serial_FLASH_CS_0_OFF;
                break;
            }
            case Serial_FLASH_CS1:
            {
                #if (Serial_FLASH_CS1 < Serial_FLASH_SPI_CHIP_SELECT)
                    Serial_FLASH_CS_1_OFF;
                #else
                    status = Serial_FLASH_DEVICE_ERROR;
                #endif
                break;
            }
            case Serial_FLASH_CS2:
            {
                #if (Serial_FLASH_CS2 < Serial_FLASH_SPI_CHIP_SELECT)
                    Serial_FLASH_CS_2_OFF;
                #else
                    status = Serial_FLASH_DEVICE_ERROR;
                #endif
                break;
            }
            case Serial_FLASH_CS3:
            {
                #if (Serial_FLASH_CS3 < Serial_FLASH_SPI_CHIP_SELECT)
                    Serial_FLASH_CS_3_OFF;
                #else
                    status = Serial_FLASH_DEVICE_ERROR;
                #endif
                break;
            }
            default:
            {
                status = Serial_FLASH_DEVICE_ERROR;
                break;
            }
        }

        return status;
    }


    /*******************************************************************************
    * Function Name:   Serial_FLASH_SpiTxBusyCheck
    ****************************************************************************//**
    *
    * Waits until the SPI bus is busy.
    *
    * \return
    * Error status
    *  * Serial_FLASH_SUCCESS - The TX transmission is complete.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does not 
    *     respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    static Serial_FLASH_status Serial_FLASH_SpiTxBusyCheck(void)
    {
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;
        uint32 timeout;

        /* Initialize a timeout */
        timeout = 0u;
        
        /* Wait for the transmission to complete */
        while ((0u != SPI_EXTMEM_SpiIsBusBusy()) || 
               (SPI_EXTMEM_INTR_MASTER_SPI_DONE != SPI_EXTMEM_GetMasterInterruptSource()))
        {
            /* Check for a communication timeout */
            if(Serial_FLASH_SPI_COM_TIMEOUT < timeout)
            {
                /* An error in the SPI communication */
                status = Serial_FLASH_TIMEOUT_ERROR;
                
                break;
            }
            timeout++;
        }
        
        SPI_EXTMEM_ClearMasterInterruptSource(SPI_EXTMEM_INTR_MASTER_SPI_DONE);
        
        return status;
    }
    
    
    /*******************************************************************************
    * Function Name:   Serial_FLASH_SpiRxBufferCheck
    ****************************************************************************//**
    *
    * Waits until the Rx buffer is empty.
    *
    * \return
    * Error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does
    *    not respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    static Serial_FLASH_status Serial_FLASH_SpiRxBufferCheck(void)
    {
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;
        uint32 timeout;

        /* Initialize a timeout */
        timeout = 0u;
        
        /* Ensure data is received in the receive buffer */
        while(0U == SPI_EXTMEM_SpiUartGetRxBufferSize())
        {
            /* Check for a communication timeout */
            if(Serial_FLASH_SPI_COM_TIMEOUT < timeout)
            {
                /* An error in the SPI communication */
                status = Serial_FLASH_TIMEOUT_ERROR;
                
                break;
            }
            timeout++;
        }  
        
        return status;
    }
    
    
    /*******************************************************************************
    * Function Name:   Serial_FLASH_SpiSetWriteEnable
    ****************************************************************************//**
    *
    * Sends the WREN command.
    *
    *  \param nvramId: CS for SPI.
    *
    * \return
    * Error status   
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does 
    *     not respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    static Serial_FLASH_status Serial_FLASH_SpiSetWriteEnable(uint8 nvramId) 
    {
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        /* Select the F-RAM device */
        status = Serial_FLASH_SpiSelectDevice(nvramId);
        
        if (Serial_FLASH_SUCCESS == status)
        {
            /* Send the WREN command */
            SPI_EXTMEM_SpiUartWriteTxData(Serial_FLASH_NVRAM_WREN);
            
            /* Wait for the transmission to complete */
            status = Serial_FLASH_SpiTxBusyCheck();
            
            /* De-select the F-RAM device  */
            (void)Serial_FLASH_SpiDeSelectDevice(nvramId);
            
            /* Wait for 1 us to form enough of pulse duration */
            CyDelayUs(1u);
        }

        return status;
    }
    
    
    /*******************************************************************************
    * Function Name:   Serial_FLASH_SpiBufferWrite
    ****************************************************************************//**
    *
    * Writes the totalDataCount number of data into NVRAM.
    *
    *  \param *dataWritePtr: The pointer to an array of data bytes to be written.
    *  \param totalDataCount: The number of data bytes to be written.
    *
    * \return
    * Error status   
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does 
    *     not respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    static Serial_FLASH_status Serial_FLASH_SpiBufferWrite(const uint8 dataWritePtr[], 
                                                                   uint32 totalDataCount) 
    {
        uint32 i;
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;
        uint32 data;

        /* Wait for the transmission to complete */
        status = Serial_FLASH_SpiTxBusyCheck();
        
        if (Serial_FLASH_SUCCESS == status)
        {
            for (i = 0u; (i < totalDataCount); i++ )
            {
                /* Get the next byte from the array of data */
                data = (uint32)dataWritePtr[i];

                /* Send the data byte */
                SPI_EXTMEM_SpiUartWriteTxData(data);
                
                /* Wait for the transmission to complete */
                status = Serial_FLASH_SpiTxBusyCheck();
            }
        }

        return status;
    }
    

    /*******************************************************************************
    * Function Name:   Serial_FLASH_SpiBufferRead
    ****************************************************************************//**
    *
    * Reads the totalDataCount number of data from the SPI Buffer. 
    *
    *  \param *dataReadPtr: The pointer to an array for storing data bytes.
    *  \param totalDataCount: The number of data bytes to be read.
    *
    * \return 
    * Error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does
    *     not respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_SpiBufferRead(uint8 dataReadPtr[], 
                                                                            uint32 totalDataCount)
    {
        uint32 i;
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;
        uint32 data;

        /* Wait for the transmission to complete */
        status = Serial_FLASH_SpiTxBusyCheck();
        
        if (Serial_FLASH_SUCCESS == status)
        {
            /*  Read the data bytes from NVRAM */
            for (i = 0u; (i < totalDataCount); i++)
            {
                /* Clear the receive buffer */
                SPI_EXTMEM_SpiUartClearRxBuffer();

                /* Send the dummy byte to receive data */
                SPI_EXTMEM_SpiUartWriteTxData(0x00U);
                
                /* Wait for the transmission to complete */
                status = Serial_FLASH_SpiTxBusyCheck();
                
                if (Serial_FLASH_SUCCESS == status)
                {
                    /* Ensure data is received in the receive buffer */
                    status = Serial_FLASH_SpiRxBufferCheck();
                    
                    /* Read the data byte and store it in the read buffer  */
                    data = SPI_EXTMEM_SpiUartReadRxData();
                    dataReadPtr[i] = (uint8)data;
                }
            }
        }

        return status;
    }
    
    
    /*******************************************************************************
    * Function Name:   Serial_FLASH_SpiMemoryWrite
    ****************************************************************************//**
    *
    * Writes the totalDataCount number of data into NVRAM.
    *
    *  \param nvramId: CS for SPI.
    *  \param addr: The 1/2/3-byte NVRAM address for Write.
    *  \param *dataWritePtr: The pointer to an array of data bytes to be written.
    *  \param totalDataCount: The number of data bytes to be written.
    *
    * \return
    *  Error status   
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does 
    *     not respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_SpiMemoryWrite(uint8 nvramId, 
                                                                             uint32 addr, 
                                                                             const uint8 *dataWritePtr, 
                                                                             uint32 totalDataCount) 
    {
        Serial_FLASH_status status;

        /* Send the WREN command */
        status = Serial_FLASH_SpiSetWriteEnable(nvramId);

        if (Serial_FLASH_SUCCESS == status)
        {
            /* Select the F-RAM device */
            (void)Serial_FLASH_SpiSelectDevice(nvramId);

            /* Send the F-RAM Write command */
            SPI_EXTMEM_SpiUartWriteTxData(Serial_FLASH_NVRAM_SRAM_WRITE_CMD);   
            
            /* For densities greater than or equal to 1MBit, send a 3-byte address */
            #if (Serial_FLASH_DENSITY_1_MBIT <= Serial_FLASH_DENSITY)
                SPI_EXTMEM_SpiUartWriteTxData((addr & Serial_FLASH_MSB_ADDR_MASK)>>Serial_FLASH_MSB_ADDR_SHIFTBITS);
            #endif
        
            /* Send a 2-byte address */
            SPI_EXTMEM_SpiUartWriteTxData((addr & Serial_FLASH_ISB_ADDR_MASK)>>Serial_FLASH_ISB_ADDR_SHIFTBITS);
            SPI_EXTMEM_SpiUartWriteTxData(addr);

            /* Send the data bytes */
            status = Serial_FLASH_SpiBufferWrite(dataWritePtr, totalDataCount);

            /* De-select the F-RAM device  */
            (void)Serial_FLASH_SpiDeSelectDevice(nvramId);
        }

        return status;
    }
    
    
    /*******************************************************************************
    * Function Name:   Serial_FLASH_SpiMemoryRead
    ****************************************************************************//**
    *
    * Reads the totalDataCount number of data from NVRAM. 
    *
    *  \param nvramId: CS for SPI.
    *  \param addr: The 1/2/3-byte NVRAM address for Write.
    *  \param *dataReadPtr: The pointer to an array for storing data bytes.
    *  \param totalDataCount: The number of data bytes to be read.
    *
    * \return 
    * Error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does 
    *     not respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_SpiMemoryRead(uint8 nvramId, 
                                                                            uint32 addr, 
                                                                            uint8 *dataReadPtr, 
                                                                            uint32 totalDataCount)
    {
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        /* Select the F-RAM device */
        status = Serial_FLASH_SpiSelectDevice(nvramId);

        if (Serial_FLASH_SUCCESS == status)
        {
            /* Send F-RAM Read command */
            SPI_EXTMEM_SpiUartWriteTxData(Serial_FLASH_NVRAM_SRAM_READ_CMD);   
            
            /* For densities greater than or equal to 1MBit, send a 3-byte address */
            #if (Serial_FLASH_DENSITY_1_MBIT <= Serial_FLASH_DENSITY)
                SPI_EXTMEM_SpiUartWriteTxData((addr & Serial_FLASH_MSB_ADDR_MASK)>>Serial_FLASH_MSB_ADDR_SHIFTBITS);
            #endif
        
            /* Send a 2-byte address */
            SPI_EXTMEM_SpiUartWriteTxData((addr & Serial_FLASH_ISB_ADDR_MASK)>>Serial_FLASH_ISB_ADDR_SHIFTBITS);
            SPI_EXTMEM_SpiUartWriteTxData(addr);

            /* Read the data bytes */
            status = Serial_FLASH_SpiBufferRead(dataReadPtr, totalDataCount);

            /* De-select the F-RAM device  */
            (void)Serial_FLASH_SpiDeSelectDevice(nvramId);
        }

        return status;
    }


    /*******************************************************************************
    * Function Name:   Serial_FLASH_SpiRtcRegWrite
    ****************************************************************************//**
    *
    * Writes the totalDataCount number of data into NVRAM RTC / F-RAM 
    * Processor Companion registers. 
    *
    *  \param nvramId: CS for SPIю
    *  \param addr: The 8-bit NVRAM RTC / F-RAM Proc companion
    *  register address for Write.
    *  \param *dataWritePtr: The pointer to an array of RTC data bytes to be written.
    *  \param totalDataCount: The number of RTC data bytes to be written.
    *
    * \return 
    * Error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does 
    *     not respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_SpiRtcRegWrite(uint8 nvramId, 
                                                                             uint32 addr, 
                                                                             const uint8 *dataWritePtr, 
                                                                             uint32 totalDataCount)
    {
        Serial_FLASH_status status;

        /* Send the WREN command */
        status = Serial_FLASH_SpiSetWriteEnable(nvramId);

        if (Serial_FLASH_SUCCESS == status)
        {
            /* Select the F-RAM device */
            (void)Serial_FLASH_SpiSelectDevice(nvramId);

            /* Send the RTC Write command */
            SPI_EXTMEM_SpiUartWriteTxData(Serial_FLASH_NVRAM_WRTC_CMD);   
                
            /* Send 1 address byte */
            SPI_EXTMEM_SpiUartWriteTxData(addr);

            /* Send the RTC data bytes */
            status = Serial_FLASH_SpiBufferWrite(dataWritePtr, totalDataCount);

            /* De-select the device  */
            (void)Serial_FLASH_SpiDeSelectDevice(nvramId); 
        }
        return status;
    }
    
    
    /*******************************************************************************
    * Function Name:   Serial_FLASH_SpiRtcRegRead
    ****************************************************************************//**
    *
    * Reads the totalDataCount number of data from nvSRAM RTC / F-RAM Processor 
    * Companion registers. 
    *
    *  \param nvramId: CS for SPI.
    *  \param addr: The 8-bit nvSRAM RTC / F-RAM Proc companion
    *  register address for Read. 
    *  \param *dataReadPtr: The pointer to an array for storing RTC data bytes.
    *  \param totalDataCount: The number of RTC data bytes to be read.
    *
    * \return 
    * Error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does 
    *     not respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_SpiRtcRegRead(uint8 nvramId, 
                                                                            uint32 addr, 
                                                                            uint8 *dataReadPtr, 
                                                                            uint32 totalDataCount)
    {
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        /* Select the F-RAM device */
        status = Serial_FLASH_SpiSelectDevice(nvramId);

        if (Serial_FLASH_SUCCESS == status)
        {
            /* Send the RTC Read command */
            SPI_EXTMEM_SpiUartWriteTxData(Serial_FLASH_NVRAM_RDRTC_CMD);   
        
            /* Send 1 address byte */
            SPI_EXTMEM_SpiUartWriteTxData(addr);
        
            /* Read the RTC data bytes */
            status = Serial_FLASH_SpiBufferRead(dataReadPtr, totalDataCount);
            
            /* De-select the device  */
            (void)Serial_FLASH_SpiDeSelectDevice(nvramId);
        }

        return status;
    }


    /*******************************************************************************
    * Function Name:   Serial_FLASH_SpiNvCommand
    ****************************************************************************//**
    *
    * Sends the NVRAM command. This is supported by nvSRAM only. 
    *
    *  \param nvramId: CS for SPI.
    *  \param nvcmd: The 8-bit NVRAM command.
    *
    * \return 
    * Error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does 
    *     not respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_SpiNvCommand(uint8 nvramId, 
                                                                           uint32 nvcmd)
    {
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        /* Send the WREN command */
        status = Serial_FLASH_SpiSetWriteEnable(nvramId);
        
        if (Serial_FLASH_SUCCESS == status)
        {
            /* Select the F-RAM device */
            (void)Serial_FLASH_SpiSelectDevice(nvramId);
            
            /* Send the nvcmd command */
            SPI_EXTMEM_SpiUartWriteTxData(nvcmd);
            
            /* Wait for the transmission to complete */
            status = Serial_FLASH_SpiTxBusyCheck();
            
            /* De-select the F-RAM device  */
            (void)Serial_FLASH_SpiDeSelectDevice(nvramId);
        }

        return status;
    }
    
    
    /*******************************************************************************
    * Function Name:   Serial_FLASH_SpiSerialNoWrite
    ****************************************************************************//**
    *
    * Writes the NVRAM Serial number.
    *
    *  \note  The processor companion devices, such as FM33256BG, 
    *  do not support this function. They have the Serial number storage 
    *  is in the RTC/companion space. 
    *  The Serial_FLASH_WriteProcessorCompanion() / 
    * Serial_FLASH_ReadProcessorCompanion()  functions are used to 
    *  write / read the serial number. Refer to the device datasheet for details. 
    *
    *  \param nvramId: CS for SPI.
    *  \param *dataPtr: The pointer to an array of serial number data to be written.
    *
    * \return
    * Error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does 
    *     not respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_SpiSerialNoWrite(uint8 nvramId, 
                                                                               const uint8 *dataPtr)
    {
        Serial_FLASH_status status;

        /* Send the WREN command */
        status = Serial_FLASH_SpiSetWriteEnable(nvramId);
        
        if (Serial_FLASH_SUCCESS == status)
        {
            /* Select the F-RAM device */
            (void)Serial_FLASH_SpiSelectDevice(nvramId);

            /* Send the Serial number Write command */
            SPI_EXTMEM_SpiUartWriteTxData(Serial_FLASH_NVRAM_WRSN_CMD);
            
            /* Send the serial number */
            status = Serial_FLASH_SpiBufferWrite(dataPtr, Serial_FLASH_SERIAL_NUM_LENGTH);

            /* De-select the F-RAM device  */
            (void)Serial_FLASH_SpiDeSelectDevice(nvramId);
        }

        return status;
    }
    
    
    /*******************************************************************************
    * Function Name:   Serial_FLASH_SpiSerialNoRead
    ****************************************************************************//**
    *
    * Reads the NVRAM Serial number.
    *
    *  \note  The processor companion devices, such as FM33256BG, 
    *  do not support this function. They have the Serial number storage 
    *  is in the RTC/companion space. 
    *  The Serial_FLASH_WriteProcessorCompanion() / 
    * Serial_FLASH_ReadProcessorCompanion()  functions are used to 
    *  write / read the serial number. Refer to the device datasheet for details.
    *
    *  \param nvramId: CS for SPI.
    *  \param *dataPtr: The pointer to an array for storing the serial number data.
    *
    * \return 
    * Error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does 
    *     not respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_SpiSerialNoRead(uint8 nvramId, 
                                                                              uint8 *dataPtr)
    {
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        /* Clear the receive buffer */
        SPI_EXTMEM_SpiUartClearRxBuffer();

        /* Select the F-RAM device */
        status = Serial_FLASH_SpiSelectDevice(nvramId);

        if (Serial_FLASH_SUCCESS == status)
        {  
            /* Send the serial number Read command */
            SPI_EXTMEM_SpiUartWriteTxData(Serial_FLASH_NVRAM_RDSN_CMD);

            /* Read the serial number data */
            status = Serial_FLASH_SpiBufferRead(dataPtr, Serial_FLASH_SERIAL_NUM_LENGTH);

            /* De-select the F-RAM device  */
            (void)Serial_FLASH_SpiDeSelectDevice(nvramId);
        }

        return status;
    }

    
    /*******************************************************************************
    * Function Name:   Serial_FLASH_SpiDevIdRead
    ****************************************************************************//**
    *
    * Reads the NVRAM Device ID. This is supported by nvSRAM and F-RAM above 128Kbit.
    * A pre-defined ID length covers the following varying device's IDs across
    * different product families: 
    *  * CY14B101PA - The DevID size is 4 bytes.
    *  * FM25VN10   - The DevID size is 9 bytes.
    *  * CY15B104Q  - The DevID size is 9 bytes.
    *  * CY14B101I  - The DevID size is 4 bytes.
    *  * FM24VN10   - The DevID size is 3 bytes.
    *  * FM31L278   - The DevID size is 8 bytes.
    *
    *  \param nvramId: CS for SPI.
    *  \param *dataPtr: The pointer to an array for storing a device ID.
    *  \param iDLength: The four predefines for the ID length:
    *         Serial_FLASH_3_BYTE_DEVICE_ID, 
    *         Serial_FLASH_4_BYTE_DEVICE_ID,
    *         Serial_FLASH_8_BYTE_DEVICE_ID, 
    *         Serial_FLASH_9_BYTE_DEVICE_ID.
    *
    * \return 
    * Error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does 
    *     not respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_SpiDevIdRead(uint8 nvramId,
                                                                           uint8 *dataPtr,
                                                                           uint32 iDLength)
    {
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        /* Clear the receive buffer */
        SPI_EXTMEM_SpiUartClearRxBuffer();

        /* Select the F-RAM device */
        status = Serial_FLASH_SpiSelectDevice(nvramId);

        if (Serial_FLASH_SUCCESS == status)
        {
            /* Send the status register Read command */
            SPI_EXTMEM_SpiUartWriteTxData(Serial_FLASH_NVRAM_RDID_CMD);

            /* Read device ID data */
            status = Serial_FLASH_SpiBufferRead(dataPtr, iDLength);
            
            /* De-select the F-RAM device  */
            (void)Serial_FLASH_SpiDeSelectDevice(nvramId);
        }

        return status;
    }
#endif


#if (Serial_FLASH_INTERFACE_I2C_SCB == Serial_FLASH_INTERFACE)
    /*******************************************************************************
    * Function Name:   Serial_FLASH_I2cDataWrite
    ****************************************************************************//**
    *
    * Sends the totalDataCount number of data.
    *
    *  \param *dataWritePtr: The pointer to an array of data bytes to be written.
    *  \param totalDataCount: The number of data bytes to be written.
    *
    * \return 
    * error status
    * *  See Serial_FLASH_I2cDataRead() function for constants.
    *
    *******************************************************************************/
    static uint32 Serial_FLASH_I2cDataWrite(const uint8 dataWritePtr[], uint32 totalDataCount)
    {
        uint32 i;
        uint32 i2cStatus = SPI_EXTMEM_I2C_MSTR_NO_ERROR;
        uint32 data;

        /* Send data bytes for Write */
        for (i = 0u; (i < totalDataCount); i++ )
        {
            /* Get the next byte from the array of data */
            data = (uint32)dataWritePtr[i];
            
            /* Send the data byte */
            i2cStatus = SPI_EXTMEM_I2CMasterWriteByte(data, Serial_FLASH_I2C_COM_TIMEOUT_MS);
                       
            if (SPI_EXTMEM_I2C_MSTR_NO_ERROR != i2cStatus)
            {
                /* An I2C error */
                break;
            }
        }

        return i2cStatus;
    }

    
    /*******************************************************************************
    * Function Name:   Serial_FLASH_I2cDataRead
    ****************************************************************************//**
    *
    * Reads the totalDataCount number of data from the I2C bus. 
    *
    *  \param *dataReadPtr: The pointer to an array for storing data bytes.
    *  \param totalDataCount: The number of data bytes to be read.
    *
    * \return 
    * error status
    *  * SPI_EXTMEM_I2C_MSTR_NO_ERROR - No errors.
    *  * SPI_EXTMEM_I2C_MSTR_BUS_BUSY - Bus is busy.
    *  Nothing was sent on the bus.
    *  * SPI_EXTMEM_I2C_MSTR_NOT_READY - Master is not ready
    *  for to start transfer.
    *  * SPI_EXTMEM_I2C_MSTR_ERR_LB_NAK - Last byte was NAKed.
    *  * SPI_EXTMEM_I2C_MSTR_ERR_ARB_LOST - Master lost arbitration.
    *  * SPI_EXTMEM_I2C_MSTR_ERR_BUS_ERR - Master encountered a bus error.
    *  * SPI_EXTMEM_I2C_MSTR_ERR_ABORT_START - The start condition
    *     generation  was aborted due to beginning of Slave operation.
    *  * SPI_EXTMEM_I2C_MSTR_ERR_TIMEOUT - The function is timed out.
    *
    *******************************************************************************/
    static uint32 Serial_FLASH_I2cDataRead(uint8 dataReadPtr[], uint32 totalDataCount)
    {
        uint32 i;
        uint32 i2cStatus = SPI_EXTMEM_I2C_MSTR_NO_ERROR;
        uint8 i2cData;
        
        /* Read array of the totalDataCount bytes with ASK data */
        for (i = 0u; (i < (totalDataCount - 1u)); i++)
        {
            i2cStatus = SPI_EXTMEM_I2CMasterReadByte(SPI_EXTMEM_I2C_ACK_DATA, 
                                                             &i2cData, 
                                                             Serial_FLASH_I2C_COM_TIMEOUT_MS);
            dataReadPtr[i] = i2cData;
        }
        
        /* Read the last byte with NAK data */
        i2cStatus = SPI_EXTMEM_I2CMasterReadByte(SPI_EXTMEM_I2C_NAK_DATA, 
                                                         &i2cData, 
                                                         Serial_FLASH_I2C_COM_TIMEOUT_MS);
        dataReadPtr[totalDataCount - 1u] = i2cData;

        return i2cStatus;
    }
    
    
    /*******************************************************************************
    * Function Name:   Serial_FLASH_I2CSendStop
    ****************************************************************************//**
    *
    * Writes the totalDataCount number of data into NVRAM.
    *
    *  \param i2cStatus: The status of the I2C communication.
    *
    * \return 
    * error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_BUSY - The I2C bus or the NVRAM device is busy.
    *  * Serial_FLASH_DEVICE_ERROR - The NVRAM device is busy or
    *   wrong last address.
    *  * Serial_FLASH_COMMUNICATION_ERROR - A communication error.
    *
    *******************************************************************************/
    static Serial_FLASH_status Serial_FLASH_I2CSendStop(uint32 i2cStatus)
    {
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        /* Check for errors */
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* No errors. Send Stop */
            i2cStatus = SPI_EXTMEM_I2CMasterSendStop(Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }
        else if ((SPI_EXTMEM_I2C_MSTR_BUS_BUSY == i2cStatus) ||
                (SPI_EXTMEM_I2C_MSTR_NOT_READY == i2cStatus))
        {
            /* The I2C bus is busy */
            status = Serial_FLASH_DEVICE_BUSY;
        }
        else if (SPI_EXTMEM_I2C_MSTR_ERR_LB_NAK == i2cStatus)     
        {
            /* The NVRAM device is busy or wrong last address */
            status = Serial_FLASH_DEVICE_ERROR;
            i2cStatus = SPI_EXTMEM_I2CMasterSendStop(Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }
        else
        {
            /* Other communications error */
            status = Serial_FLASH_COMMUNICATION_ERROR;
            i2cStatus = SPI_EXTMEM_I2CMasterSendStop(Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }

        return status;
    }
    

    /*******************************************************************************
    * Function Name:   Serial_FLASH_I2cMemoryWrite
    ****************************************************************************//**
    *
    * Writes the totalDataCount number of data into NVRAM.
    *
    *  \param nvramId: The slave address for I2C.
    *  For I2C devices see the detailed format in
    *  Serial_FLASH_GetStatus() description.
    *  \param addr: The 1/2/3-byte NVRAM address for Write.
    *  \param *dataWritePtr: The pointer to an array of data bytes to be written.
    *  \param totalDataCount: The number of data bytes to be written.
    *
    * \return 
    * error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_BUSY - The I2C bus or the NVRAM device is busy.
    *  * Serial_FLASH_COMMUNICATION_ERROR - A communication error.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cMemoryWrite(uint8 nvramId, 
                                                                             uint32 addr, 
                                                                             const uint8 *dataWritePtr, 
                                                                             uint32 totalDataCount) 
    {
        uint32 i2cStatus;

        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        /* Apply the mask to unused bits */
        nvramId = nvramId & Serial_FLASH_I2C_SLAVE_ADDR_MASK; 
        
        /* Set the I2C Memory selection mask */
        nvramId |= Serial_FLASH_NVRAM_SEL_MEM_MASK;
        
        /* For densities > 1-Mbit, add the MSB bit in in the slave ID (bit0) */
        #if (Serial_FLASH_DENSITY_1_MBIT <= Serial_FLASH_DENSITY)
            nvramId |= (uint8)(((addr & Serial_FLASH_MSBIT_MASK)>>Serial_FLASH_MSB_ADDR_SHIFTBITS) &
                              Serial_FLASH_LSBIT_MASK);
        #endif

        /* Send the Start condition and slave ID for Write */
        i2cStatus = SPI_EXTMEM_I2CMasterSendStart((uint32)nvramId, 
                                                          SPI_EXTMEM_I2C_WRITE_XFER_MODE, 
                                                          Serial_FLASH_I2C_COM_TIMEOUT_MS);
        
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the ISB address byte */
            i2cStatus = SPI_EXTMEM_I2CMasterWriteByte(((addr & Serial_FLASH_ISB_ADDR_MASK)
                                                               >>Serial_FLASH_ISB_ADDR_SHIFTBITS), 
                                                             Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }

        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the LSB address byte */
            i2cStatus = SPI_EXTMEM_I2CMasterWriteByte(addr, Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }
        
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send data bytes for Write */
            i2cStatus = Serial_FLASH_I2cDataWrite(dataWritePtr, totalDataCount);
        }
        
        /* Send Stop and get the error status */
        status = Serial_FLASH_I2CSendStop(i2cStatus);

        return status;
    }
    
    
    /*******************************************************************************
    * Function Name:   Serial_FLASH_I2cMemoryRead
    ****************************************************************************//**
    *
    * Reads the totalDataCount number of data from NVRAM. 
    *
    *  \param nvramId: The slave address for I2C.
    *  For I2C devices see the detailed format in
    *  Serial_FLASH_GetStatus() description.
    *  \param addr: The 1/2/3-byte NVRAM address for Write.
    *  \param *dataReadPtr: The pointer to an array for storing data bytes.
    *  \param totalDataCount: The number of the data bytes to be read.
    *
    * \return 
    * error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_COMMUNICATION_ERROR - A communication error.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cMemoryRead(uint8 nvramId, 
                                                                            uint32 addr, 
                                                                            uint8 *dataReadPtr, 
                                                                            uint32 totalDataCount)
    {
        uint32 i2cStatus;
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;
    
        /* Apply the mask to unused bits */
        nvramId = nvramId & Serial_FLASH_I2C_SLAVE_ADDR_MASK; 
        
        /* Set the I2C Memory selection mask */
        nvramId |= Serial_FLASH_NVRAM_SEL_MEM_MASK;
    
        /* For densities > 1-Mbit, add the MSB bit in the slave ID (bit0) */
        #if (Serial_FLASH_DENSITY_1_MBIT <= Serial_FLASH_DENSITY)
            nvramId |= (uint8)(((addr & Serial_FLASH_MSBIT_MASK)>>Serial_FLASH_MSB_ADDR_SHIFTBITS) &
                              Serial_FLASH_LSBIT_MASK);
        #endif

        /* Send the Start condition and slave ID for Write */
        i2cStatus = SPI_EXTMEM_I2CMasterSendStart((uint32)nvramId, 
                                                          SPI_EXTMEM_I2C_WRITE_XFER_MODE, 
                                                          Serial_FLASH_I2C_COM_TIMEOUT_MS);
        
        /* Write the SRAM address to the slave */
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the ISB address byte */
            i2cStatus = SPI_EXTMEM_I2CMasterWriteByte(((addr & Serial_FLASH_ISB_ADDR_MASK)
                                                              >>Serial_FLASH_ISB_ADDR_SHIFTBITS), 
                                                             Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }

        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the LSB address byte */
            i2cStatus = SPI_EXTMEM_I2CMasterWriteByte(addr, Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }

        /* Read data from the slave */
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the ReStart condition and slave ID for Read */
            i2cStatus = SPI_EXTMEM_I2CMasterSendRestart((uint32)nvramId, 
                                                                SPI_EXTMEM_I2C_READ_XFER_MODE, 
                                                                Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }

        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Read the array of totalDataCount bytes */
            i2cStatus = Serial_FLASH_I2cDataRead(dataReadPtr, totalDataCount);
        }
        
        /* Send Stop and get the error status */
        status = Serial_FLASH_I2CSendStop(i2cStatus);

        return status;
    }
    
    
    /*******************************************************************************
    * Function Name:   Serial_FLASH_I2cRtcRegWrite
    ****************************************************************************//**
    *
    * Writes the totalDataCount number of data into NVRAM RTC / F-RAM 
    * Processor Companion registers. 
    *
    *  \param nvramId: The slave address for I2C.
    *  For I2C devices see the detailed format in
    *  Serial_FLASH_GetStatus() description.
    *  \param addr: The 8-bit NVRAM RTC/F-RAM Proc companion
    *   register address for Write.
    *  \param *dataWritePtr: The pointer to an array of the RTC
    *  data bytes to be written.
    *  \param totalDataCount: The number of the RTC data bytes to be written.
    *
    * \return 
    * error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_COMMUNICATION_ERROR - A communication error.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cRtcRegWrite(uint8 nvramId, 
                                                                             uint32 addr, 
                                                                             const uint8 *dataWritePtr, 
                                                                             uint32 totalDataCount)
    {
        uint32 i2cStatus;
        Serial_FLASH_status  status = Serial_FLASH_SUCCESS;
        
        /* Apply the mask to unused bits */
        nvramId = nvramId & Serial_FLASH_I2C_SLAVE_ADDR_MASK; 
       
        /* Set RTC Registers selection mask */
        nvramId = nvramId | Serial_FLASH_NVRAM_SEL_RTCR_MASK;

        /*  Send the Start condition and slave ID for Write */
        i2cStatus = SPI_EXTMEM_I2CMasterSendStart((uint32)nvramId, 
                                                          SPI_EXTMEM_I2C_WRITE_XFER_MODE, 
                                                          Serial_FLASH_I2C_COM_TIMEOUT_MS);
        
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the register address byte */
            i2cStatus = SPI_EXTMEM_I2CMasterWriteByte(addr, Serial_FLASH_I2C_COM_TIMEOUT_MS);
        
            if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
            {
                /* Send the data bytes for Write */
                i2cStatus = Serial_FLASH_I2cDataWrite(dataWritePtr, totalDataCount);
            }
        }

        /* Send Stop and get the error status */
        status = Serial_FLASH_I2CSendStop(i2cStatus);     

        return status;
    }


    /*******************************************************************************
    * Function Name:   Serial_FLASH_I2cRtcRegRead
    ****************************************************************************//**
    *
    * Reads the totalDataCount number of data from nvSRAM RTC/F-RAM Processor 
    * Companion registers. 
    *
    *  \param nvramId: The slave address for I2C.
    *  For I2C devices see the detailed format in
    *  Serial_FLASH_GetStatus() description.
    *  \param addr: The 8-bit nvSRAM RTC/F-RAM Proc companion register address for Read.
    *  \param *dataReadPtr: The pointer to an array for storing the RTC data bytes.
    *  \param totalDataCount: The number of the RTC data bytes to be read.
    *
    * \return 
    * error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_COMMUNICATION_ERROR - A communication error.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cRtcRegRead(uint8 nvramId, 
                                                                            uint32 addr, 
                                                                            uint8 *dataReadPtr, 
                                                                            uint32 totalDataCount)
    {
        uint32 i2cStatus;
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        /* Apply the mask to unused bits */
        nvramId = nvramId & Serial_FLASH_I2C_SLAVE_ADDR_MASK; 
       
        /* Set RTC Registers selection mask */
        nvramId = nvramId | Serial_FLASH_NVRAM_SEL_RTCR_MASK;

        /* Send the Start condition and slave ID for Write */
        i2cStatus = SPI_EXTMEM_I2CMasterSendStart((uint32)nvramId, 
                                                          SPI_EXTMEM_I2C_WRITE_XFER_MODE, 
                                                          Serial_FLASH_I2C_COM_TIMEOUT_MS);
        
        /* Write the SRAM address to the slave */
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the RTC register address byte */
            i2cStatus = SPI_EXTMEM_I2CMasterWriteByte(addr, Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }
        
        /* Read data from the slave */
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the ReStart condition and slave ID for Read */
            i2cStatus = SPI_EXTMEM_I2CMasterSendRestart((uint32)nvramId, 
                                                                SPI_EXTMEM_I2C_READ_XFER_MODE, 
                                                                Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }

        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Read the array of the totalDataCount bytes */
            i2cStatus = Serial_FLASH_I2cDataRead(dataReadPtr, totalDataCount);
        }
        
        /* Send Stop and get the error status */
        status = Serial_FLASH_I2CSendStop(i2cStatus);
        
        return status;
    }


    /*******************************************************************************
    * Function Name:   Serial_FLASH_I2cNvCommand
    ****************************************************************************//**
    *
    * Sends the NVRAM command. This is supported by nvSRAM only. 
    *
    *  \param nvramId: The slave address for I2C.
    *  For I2C devices see the detailed format in
    *  Serial_FLASH_GetStatus() description.
    *  \param nvcmd: The 8-bit NVRAM command.
    *
    * \return 
    * Error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_COMMUNICATION_ERROR - A communication error.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cNvCommand(uint8 nvramId, 
                                                                           uint32 nvcmd)
    {
        uint32 i2cStatus;
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        /* Apply the mask to unused bits */
        nvramId = nvramId & Serial_FLASH_I2C_SLAVE_ADDR_MASK; 
       
        /* Set the Control Registers Slave Address */
        nvramId = nvramId | Serial_FLASH_NVRAM_SEL_CR_MASK;

        /*  Send the Start condition and slave ID for Write */
        i2cStatus = SPI_EXTMEM_I2CMasterSendStart((uint32)nvramId, 
                                                          SPI_EXTMEM_I2C_WRITE_XFER_MODE, 
                                                          Serial_FLASH_I2C_COM_TIMEOUT_MS);
        
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the Command Register address */
            i2cStatus = SPI_EXTMEM_I2CMasterWriteByte(Serial_FLASH_COMMAND_REG_ADDR, 
                                                              Serial_FLASH_I2C_COM_TIMEOUT_MS);
        
            if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
            {
               /* Send the data byte for Write */
               i2cStatus = SPI_EXTMEM_I2CMasterWriteByte(nvcmd, Serial_FLASH_I2C_COM_TIMEOUT_MS);
            }
        }

        /* Send Stop and get the error status */
        status = Serial_FLASH_I2CSendStop(i2cStatus);

        return status;
    }
   
   
    /*******************************************************************************
    * Function Name:   Serial_FLASH_I2cSerialNoWrite
    ****************************************************************************//**
    *
    * Writes the NVRAM Serial number. 
    *
    *  \param nvramId: The slave address for I2C.
    *  For I2C devices see the detailed format in
    *  Serial_FLASH_GetStatus() description.
    *  \param *dataPtr: The pointer to an array of serial number data to be written.
    *
    * \return
    * error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_COMMUNICATION_ERROR - A communication error.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cSerialNoWrite(uint8 nvramId,
                                                                               const uint8 *dataPtr)
    {
        uint32 i2cStatus;
        Serial_FLASH_status  status = Serial_FLASH_SUCCESS;

        /* Apply the mask to unused bits */
        nvramId = nvramId & Serial_FLASH_I2C_SLAVE_ADDR_MASK; 
       
        /* Set the Control Registers Slave Address */
        nvramId = nvramId | Serial_FLASH_NVRAM_SEL_CR_MASK;

        /*  Send the Start condition and slave ID for Write */
        i2cStatus = SPI_EXTMEM_I2CMasterSendStart((uint32)nvramId, 
                                                          SPI_EXTMEM_I2C_WRITE_XFER_MODE, 
                                                          Serial_FLASH_I2C_COM_TIMEOUT_MS);
        
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the Serial Number address byte */
            i2cStatus = SPI_EXTMEM_I2CMasterWriteByte(Serial_FLASH_SERIAL_NUM_REG_ADDR,
                                                              Serial_FLASH_I2C_COM_TIMEOUT_MS);
        
            if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
            {
                /* Send the data bytes for Write */
                i2cStatus = Serial_FLASH_I2cDataWrite(dataPtr, Serial_FLASH_SERIAL_NUM_LENGTH);
            }
        }

        /* Send Stop and get the error status */
        status = Serial_FLASH_I2CSendStop(i2cStatus);  
        
        return status;
    }
   
        
    /*******************************************************************************
    * Function Name:   Serial_FLASH_I2cSerialNoRead
    ****************************************************************************//**
    *
    * Reads the NVRAM Serial number.
    *
    *  \param nvramId: The slave address for I2C.
    *  For I2C devices see the detailed format in
    *  Serial_FLASH_GetStatus() description.
    *  \param *dataPtr: The pointer to an array for storing the serial number data.
    *
    * \return 
    * error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_COMMUNICATION_ERROR - A communication error.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cSerialNoRead(uint8 nvramId,
                                                                              uint8 *dataPtr)
    {
        uint32 i2cStatus;
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        /* Apply the mask to unused bits */
        nvramId = nvramId & Serial_FLASH_I2C_SLAVE_ADDR_MASK; 
       
        /* Set the Control Registers Slave Address */
        nvramId = nvramId | Serial_FLASH_NVRAM_SEL_CR_MASK;

        /* Send the Start condition and slave ID */
        i2cStatus = SPI_EXTMEM_I2CMasterSendStart((uint32)nvramId, 
                                                          SPI_EXTMEM_I2C_WRITE_XFER_MODE,
                                                          Serial_FLASH_I2C_COM_TIMEOUT_MS);
        
        /* Write the Serial Number address to the slave */
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the LSB address byte */
            i2cStatus = SPI_EXTMEM_I2CMasterWriteByte(Serial_FLASH_SERIAL_NUM_REG_ADDR,
                                                              Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }
        
        /* Read data from the slave */
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the ReStart condition and slave ID for Read */
            i2cStatus = SPI_EXTMEM_I2CMasterSendRestart((uint32)nvramId,
                                                                SPI_EXTMEM_I2C_READ_XFER_MODE,
                                                                Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }

        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Read the array of Serial_FLASH_SERIAL_NUM_LENGTH bytes */
            i2cStatus = Serial_FLASH_I2cDataRead(dataPtr, Serial_FLASH_SERIAL_NUM_LENGTH);
        }
        
        /* Send Stop and get the error status */
        status = Serial_FLASH_I2CSendStop(i2cStatus);
        
        return status;
    }  

    
    /*******************************************************************************
    * Function Name:   Serial_FLASH_I2cUniqueSleep
    ****************************************************************************//**
    *
    * Sends the NVRAM command for sleep for the I2C devices with
    *  the unique serial number. (Example, FM24V10).
    *
    *  \param nvramId: Еhe slave address for I2C
    *  The nvramId parameter for the FM24VN10 families has the following format: 
    *  0 1 0 1 0 A2 A1 A16. 
    *  Bits A2 and A1 are the slave address inputs. 
    *  Bit A16 is the page select bit and it can have any value for this function. 
    *  Four FM24VN10 devices can be connected to I2C bus with the following
    *  nvramId parameter values:
    *  * 0x50 - Both A2 and A1 pins are connected to the ground.
    *  * 0x52 - Pin A2 connected to the ground and Pin A1 connected to the high level.
    *  * 0x54 - Pin A2 connected to the high level and Pin A1 connected to the ground.
    *  * 0x56 – Both A2 and A1 pins are connected to the high level.
    *
    * \return 
    * Error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_TIMEOUT_ERROR - The device does not 
    *     respond or Serial_FLASH_SPI_COM_TIMEOUT elapsed.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cUniqueSleep(uint8 nvramId)
    {
        uint32 i2cStatus;
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        /* Apply the mask to unused bits */
        nvramId = (nvramId & Serial_FLASH_I2C_RSVD_SLAVE_ADDR_MASK) << 1u; 
        
        /* Send the Start condition and Reserved Slave ID */
        i2cStatus = SPI_EXTMEM_I2CMasterSendStart(Serial_FLASH_RSVD_SLAVE_ID, 
                                                          SPI_EXTMEM_I2C_WRITE_XFER_MODE, 
                                                          Serial_FLASH_I2C_COM_TIMEOUT_MS);
        
        /* Write the slave ID to the slave */
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the address byte */
            i2cStatus = SPI_EXTMEM_I2CMasterWriteByte((uint32)nvramId, Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }

        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the ReStart condition and Reserved Slave ID */
            (void)SPI_EXTMEM_I2CMasterSendRestart(Serial_FLASH_RSVD_SLAVE_SLEEP_ID, 
                                                                SPI_EXTMEM_I2C_WRITE_XFER_MODE, 
                                                                Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }
        
        /* Send Stop and get the error status */
        status = Serial_FLASH_I2CSendStop(i2cStatus);
        
        return status;
    }

        
    /*******************************************************************************
    * Function Name:   Serial_FLASH_I2cUniqueSerialNoRead
    ****************************************************************************//**
    *
    * Reads the NVRAM Serial number for the I2C devices with
    *  the unique serial number. (Example, FM24V10).
    *
    *  \param nvramId: The slave address for I2C.
    *  The nvramId parameter for the FM24VN10 families has the following format: 
    *  0 1 0 1 0 A2 A1 A16. 
    *  Bits A2 and A1 are the slave address inputs. 
    *  Bit A16 is the page select bit and it can have any value for this function. 
    *  Four FM24VN10 devices can be connected to I2C bus with the following
    *  nvramId parameter values:
    *  * 0x50 - Both A2 and A1 pins are connected to the ground.
    *  * 0x52 - Pin A2 connected to the ground and Pin A1 connected to the high level.
    *  * 0x54 - Pin A2 connected to the high level and Pin A1 connected to the ground.
    *  * 0x56 – Both A2 and A1 pins are connected to the high level.
    *  \param *dataPtr: The pointer to an array for storing the serial number data.
    *
    * \return 
    * error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_COMMUNICATION_ERROR - A communication error.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cUniqueSerialNoRead(uint8 nvramId,
                                                                                    uint8 *dataPtr)
    {
        uint32 i2cStatus;
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        /* Apply the mask to unused bits */
        nvramId = (nvramId & Serial_FLASH_I2C_RSVD_SLAVE_ADDR_MASK) << 1u; 
        
        /* Send the Start condition and Reserved Slave ID */
        i2cStatus = SPI_EXTMEM_I2CMasterSendStart(Serial_FLASH_RSVD_SLAVE_ID, 
                                                          SPI_EXTMEM_I2C_WRITE_XFER_MODE, 
                                                          Serial_FLASH_I2C_COM_TIMEOUT_MS);
        
        /* Write the slave ID to the slave */
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the LSB address byte */
            i2cStatus = SPI_EXTMEM_I2CMasterWriteByte((uint32)nvramId, Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }

        /* Read data from the slave */
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the ReStart condition and Reserved Slave ID to read the serial number. */
            i2cStatus = SPI_EXTMEM_I2CMasterSendRestart(Serial_FLASH_RSVD_SLAVE_SERIAL_NUM_ID, 
                                                                SPI_EXTMEM_I2C_READ_XFER_MODE, 
                                                                Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }

        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Read the array of Serial_FLASH_SERIAL_NUM_LENGTH bytes */
            i2cStatus = Serial_FLASH_I2cDataRead(dataPtr, Serial_FLASH_SERIAL_NUM_LENGTH);
        }
        
        /* Send Stop and get the error status */
        status = Serial_FLASH_I2CSendStop(i2cStatus);
        
        return status;
    }
    
    
    /*******************************************************************************
    * Function Name:   Serial_FLASH_I2cUniqueDevIdRead
    ****************************************************************************//**
    *
    * Reads the NVRAM device ID for the devices with unique serial number
    * (for example, FM24VN10 device).
    * A pre-defined ID length covers the following varying device's IDs across
    * different product families: 
    *  * FM24VN10   - The DevID size is 3 bytes.
    *
    *  \param nvramId: The slave address for I2C.
    *  The nvramId parameter for the FM24VN10 families has the following format: 
    *  0 1 0 1 0 A2 A1 A16. 
    *  Bits A2 and A1 are the slave address inputs. 
    *  Bit A16 is the page select bit and it can have any value for this function. 
    *  Four FM24VN10 devices can be connected to I2C bus with the following
    *  nvramId parameter values:
    *  * 0x50 - Both A2 and A1 pins are connected to the ground.
    *  * 0x52 - Pin A2 connected to the ground and Pin A1 connected to the high level.
    *  * 0x54 - Pin A2 connected to the high level and Pin A1 connected to the ground.
    *  * 0x56 – Both A2 and A1 pins are connected to the high level.
    *  \param *dataPtr: The pointer to an array for storing the device ID.
    *  \param IDLength: The ID length (3ByteDeviceID for the FM24VN10 device).    
    *
    * \return 
    * Error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cUniqueDevIdRead(uint8 nvramId,
                                                                           uint8 *dataPtr,
                                                                           uint32 iDLength)
    {
        uint32 i2cStatus;
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;

        /* Apply the mask to unused bits */
        nvramId = (nvramId & Serial_FLASH_I2C_RSVD_SLAVE_ADDR_MASK) << 1u; 
        
        /* Send the Start condition and Reserved Slave ID */
        i2cStatus = SPI_EXTMEM_I2CMasterSendStart(Serial_FLASH_RSVD_SLAVE_ID, 
                                                          SPI_EXTMEM_I2C_WRITE_XFER_MODE, 
                                                          Serial_FLASH_I2C_COM_TIMEOUT_MS);

        /* Write the slave ID to the slave */
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the LSB address byte */
            i2cStatus = SPI_EXTMEM_I2CMasterWriteByte((uint32)nvramId, Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }

        /* Read data from the slave */
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the ReStart condition and Reserved Slave ID to read the device ID */
            i2cStatus = SPI_EXTMEM_I2CMasterSendRestart(Serial_FLASH_RSVD_SLAVE_DEV_ID, 
                                                                SPI_EXTMEM_I2C_READ_XFER_MODE, 
                                                                Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }

        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Read the array of Serial_FLASH_SERIAL_NUM_LENGTH bytes */
            i2cStatus = Serial_FLASH_I2cDataRead(dataPtr, iDLength);
        }

        /* Send Stop and get the error status */
        status = Serial_FLASH_I2CSendStop(i2cStatus);

        return status;
    }

    /*******************************************************************************
    * Function Name:   Serial_FLASH_I2cDevIdRead
    ****************************************************************************//**
    *
    * Reads the NVRAM device ID. This is supported by nvSRAM and F-RAM above 128Kbit.
    * A pre-defined ID length covers the following varying device IDs across
    * different product families: 
    *  * CY14B101PA - The DevID size is 4 bytes.
    *  * FM25VN10   - The DevID size is 9 bytes.
    *  * CY15B104Q  - The DevID size is 9 bytes.
    *  * CY14B101I  - The DevID size is 4 bytes.
    *  * FM31L278   - The DevID size is 8 bytes.
    *
    *  \note This function is not applicable for the FM24VN10 devices. 
    *  The Serial_FLASH_UniqueDevIdRead() function is used
    *  FM24VN10 devices. For more detail, refer to the device datasheet.
    *
    *  \param nvramId: The slave address for I2C.
    *  For I2C devices see the detailed format in
    *  Serial_FLASH_GetStatus() description.
    *  \param *dataPtr: The pointer to an array for storing the device ID.
    *  \param iDLength: The four pre-defines for the ID length (3ByteDeviceID, 
    *         4ByteDeviceID, 8ByteDeviceID, 9ByteDeviceID).
    *
    * \return 
    * error status
    *  * Serial_FLASH_SUCCESS - No errors.
    *  * Serial_FLASH_DEVICE_ERROR - The wrong device or a device error.
    *  * Serial_FLASH_COMMUNICATION_ERROR - A communication error.
    *
    *******************************************************************************/
    CY_INLINE static Serial_FLASH_status Serial_FLASH_I2cDevIdRead(uint8 nvramId,
                                                                           uint8 *dataPtr,
                                                                           uint32 iDLength)
    {
        uint32 i2cStatus;
        Serial_FLASH_status status = Serial_FLASH_SUCCESS;
    
        /* Apply the mask to unused bits */
        nvramId = nvramId & Serial_FLASH_I2C_SLAVE_ADDR_MASK; 
       
        /* Set the Control Registers Slave Address */
        nvramId = nvramId | Serial_FLASH_NVRAM_SEL_CR_MASK;

        /* Send the Start condition and slave ID for Write */
        i2cStatus = SPI_EXTMEM_I2CMasterSendStart((uint32)nvramId, 
                                                          SPI_EXTMEM_I2C_WRITE_XFER_MODE,
                                                          Serial_FLASH_I2C_COM_TIMEOUT_MS);
        
        /* Write the Device ID address to the slave */
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the LSB address byte */
            i2cStatus = SPI_EXTMEM_I2CMasterWriteByte(Serial_FLASH_DEVICE_ID_REG_ADDR,
                                                              Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }
        
        /* Read data from the slave */
        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Send the ReStart condition and slave ID for Read */
            i2cStatus = SPI_EXTMEM_I2CMasterSendRestart((uint32)nvramId, 
                                                                SPI_EXTMEM_I2C_READ_XFER_MODE,
                                                                Serial_FLASH_I2C_COM_TIMEOUT_MS);
        }

        if (SPI_EXTMEM_I2C_MSTR_NO_ERROR == i2cStatus)
        {
            /* Read the array of iDLength bytes */
            i2cStatus = Serial_FLASH_I2cDataRead(dataPtr, iDLength);
        }
        
        /* Send Stop and get the error status */
        status = Serial_FLASH_I2CSendStop(i2cStatus);

        return status;
    }    
#endif


/* [] END OF FILE */
