/***************************************************************************//**
* \file .h
* \version 4.0
*
* \brief
*  This private file provides constants and parameter values for the
*  SCB Component.
*  Please do not use this file or its content in your project.
*
* Note:
*
********************************************************************************
* \copyright
* Copyright 2013-2017, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_PVT_SPI_EXTMEM_H)
#define CY_SCB_PVT_SPI_EXTMEM_H

#include "SPI_EXTMEM.h"


/***************************************
*     Private Function Prototypes
***************************************/

/* APIs to service INTR_I2C_EC register */
#define SPI_EXTMEM_SetI2CExtClkInterruptMode(interruptMask) SPI_EXTMEM_WRITE_INTR_I2C_EC_MASK(interruptMask)
#define SPI_EXTMEM_ClearI2CExtClkInterruptSource(interruptMask) SPI_EXTMEM_CLEAR_INTR_I2C_EC(interruptMask)
#define SPI_EXTMEM_GetI2CExtClkInterruptSource()                (SPI_EXTMEM_INTR_I2C_EC_REG)
#define SPI_EXTMEM_GetI2CExtClkInterruptMode()                  (SPI_EXTMEM_INTR_I2C_EC_MASK_REG)
#define SPI_EXTMEM_GetI2CExtClkInterruptSourceMasked()          (SPI_EXTMEM_INTR_I2C_EC_MASKED_REG)

#if (!SPI_EXTMEM_CY_SCBIP_V1)
    /* APIs to service INTR_SPI_EC register */
    #define SPI_EXTMEM_SetSpiExtClkInterruptMode(interruptMask) \
                                                                SPI_EXTMEM_WRITE_INTR_SPI_EC_MASK(interruptMask)
    #define SPI_EXTMEM_ClearSpiExtClkInterruptSource(interruptMask) \
                                                                SPI_EXTMEM_CLEAR_INTR_SPI_EC(interruptMask)
    #define SPI_EXTMEM_GetExtSpiClkInterruptSource()                 (SPI_EXTMEM_INTR_SPI_EC_REG)
    #define SPI_EXTMEM_GetExtSpiClkInterruptMode()                   (SPI_EXTMEM_INTR_SPI_EC_MASK_REG)
    #define SPI_EXTMEM_GetExtSpiClkInterruptSourceMasked()           (SPI_EXTMEM_INTR_SPI_EC_MASKED_REG)
#endif /* (!SPI_EXTMEM_CY_SCBIP_V1) */

#if(SPI_EXTMEM_SCB_MODE_UNCONFIG_CONST_CFG)
    extern void SPI_EXTMEM_SetPins(uint32 mode, uint32 subMode, uint32 uartEnableMask);
#endif /* (SPI_EXTMEM_SCB_MODE_UNCONFIG_CONST_CFG) */


/***************************************
*     Vars with External Linkage
***************************************/

#if (SPI_EXTMEM_SCB_IRQ_INTERNAL)
#if !defined (CY_REMOVE_SPI_EXTMEM_CUSTOM_INTR_HANDLER)
    extern cyisraddress SPI_EXTMEM_customIntrHandler;
#endif /* !defined (CY_REMOVE_SPI_EXTMEM_CUSTOM_INTR_HANDLER) */
#endif /* (SPI_EXTMEM_SCB_IRQ_INTERNAL) */

extern SPI_EXTMEM_BACKUP_STRUCT SPI_EXTMEM_backup;

#if(SPI_EXTMEM_SCB_MODE_UNCONFIG_CONST_CFG)
    /* Common configuration variables */
    extern uint8 SPI_EXTMEM_scbMode;
    extern uint8 SPI_EXTMEM_scbEnableWake;
    extern uint8 SPI_EXTMEM_scbEnableIntr;

    /* I2C configuration variables */
    extern uint8 SPI_EXTMEM_mode;
    extern uint8 SPI_EXTMEM_acceptAddr;

    /* SPI/UART configuration variables */
    extern volatile uint8 * SPI_EXTMEM_rxBuffer;
    extern uint8   SPI_EXTMEM_rxDataBits;
    extern uint32  SPI_EXTMEM_rxBufferSize;

    extern volatile uint8 * SPI_EXTMEM_txBuffer;
    extern uint8   SPI_EXTMEM_txDataBits;
    extern uint32  SPI_EXTMEM_txBufferSize;

    /* EZI2C configuration variables */
    extern uint8 SPI_EXTMEM_numberOfAddr;
    extern uint8 SPI_EXTMEM_subAddrSize;
#endif /* (SPI_EXTMEM_SCB_MODE_UNCONFIG_CONST_CFG) */

#if (! (SPI_EXTMEM_SCB_MODE_I2C_CONST_CFG || \
        SPI_EXTMEM_SCB_MODE_EZI2C_CONST_CFG))
    extern uint16 SPI_EXTMEM_IntrTxMask;
#endif /* (! (SPI_EXTMEM_SCB_MODE_I2C_CONST_CFG || \
              SPI_EXTMEM_SCB_MODE_EZI2C_CONST_CFG)) */


/***************************************
*        Conditional Macro
****************************************/

#if(SPI_EXTMEM_SCB_MODE_UNCONFIG_CONST_CFG)
    /* Defines run time operation mode */
    #define SPI_EXTMEM_SCB_MODE_I2C_RUNTM_CFG     (SPI_EXTMEM_SCB_MODE_I2C      == SPI_EXTMEM_scbMode)
    #define SPI_EXTMEM_SCB_MODE_SPI_RUNTM_CFG     (SPI_EXTMEM_SCB_MODE_SPI      == SPI_EXTMEM_scbMode)
    #define SPI_EXTMEM_SCB_MODE_UART_RUNTM_CFG    (SPI_EXTMEM_SCB_MODE_UART     == SPI_EXTMEM_scbMode)
    #define SPI_EXTMEM_SCB_MODE_EZI2C_RUNTM_CFG   (SPI_EXTMEM_SCB_MODE_EZI2C    == SPI_EXTMEM_scbMode)
    #define SPI_EXTMEM_SCB_MODE_UNCONFIG_RUNTM_CFG \
                                                        (SPI_EXTMEM_SCB_MODE_UNCONFIG == SPI_EXTMEM_scbMode)

    /* Defines wakeup enable */
    #define SPI_EXTMEM_SCB_WAKE_ENABLE_CHECK       (0u != SPI_EXTMEM_scbEnableWake)
#endif /* (SPI_EXTMEM_SCB_MODE_UNCONFIG_CONST_CFG) */

/* Defines maximum number of SCB pins */
#if (!SPI_EXTMEM_CY_SCBIP_V1)
    #define SPI_EXTMEM_SCB_PINS_NUMBER    (7u)
#else
    #define SPI_EXTMEM_SCB_PINS_NUMBER    (2u)
#endif /* (!SPI_EXTMEM_CY_SCBIP_V1) */

#endif /* (CY_SCB_PVT_SPI_EXTMEM_H) */


/* [] END OF FILE */
