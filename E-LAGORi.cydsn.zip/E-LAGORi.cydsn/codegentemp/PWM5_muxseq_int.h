/*******************************************************************************
* File Name: PWM5_muxseq_int.h
* Version 1.71
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_PWM5_muxseq_int_H)
#define CY_ISR_PWM5_muxseq_int_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void PWM5_muxseq_int_Start(void);
void PWM5_muxseq_int_StartEx(cyisraddress address);
void PWM5_muxseq_int_Stop(void);

CY_ISR_PROTO(PWM5_muxseq_int_Interrupt);

void PWM5_muxseq_int_SetVector(cyisraddress address);
cyisraddress PWM5_muxseq_int_GetVector(void);

void PWM5_muxseq_int_SetPriority(uint8 priority);
uint8 PWM5_muxseq_int_GetPriority(void);

void PWM5_muxseq_int_Enable(void);
uint8 PWM5_muxseq_int_GetState(void);
void PWM5_muxseq_int_Disable(void);

void PWM5_muxseq_int_SetPending(void);
void PWM5_muxseq_int_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the PWM5_muxseq_int ISR. */
#define PWM5_muxseq_int_INTC_VECTOR            ((reg32 *) PWM5_muxseq_int__INTC_VECT)

/* Address of the PWM5_muxseq_int ISR priority. */
#define PWM5_muxseq_int_INTC_PRIOR             ((reg32 *) PWM5_muxseq_int__INTC_PRIOR_REG)

/* Priority of the PWM5_muxseq_int interrupt. */
#define PWM5_muxseq_int_INTC_PRIOR_NUMBER      PWM5_muxseq_int__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable PWM5_muxseq_int interrupt. */
#define PWM5_muxseq_int_INTC_SET_EN            ((reg32 *) PWM5_muxseq_int__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the PWM5_muxseq_int interrupt. */
#define PWM5_muxseq_int_INTC_CLR_EN            ((reg32 *) PWM5_muxseq_int__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the PWM5_muxseq_int interrupt state to pending. */
#define PWM5_muxseq_int_INTC_SET_PD            ((reg32 *) PWM5_muxseq_int__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the PWM5_muxseq_int interrupt. */
#define PWM5_muxseq_int_INTC_CLR_PD            ((reg32 *) PWM5_muxseq_int__INTC_CLR_PD_REG)



#endif /* CY_ISR_PWM5_muxseq_int_H */


/* [] END OF FILE */
